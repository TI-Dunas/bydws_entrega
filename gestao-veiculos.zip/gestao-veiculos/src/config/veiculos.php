<?php

/*
| Mapeamento homologado da planilha operacional (seção 4 da especificação).
| 'header' é o cabeçalho exato exigido na importação; 'grupo' define o bloco
| e, por consequência, qual perfil pode editar o campo.
*/

return [

    'grupos' => [
        'principal'    => 'Identificação e vendas',
        'logistica'    => 'Acompanhamento e logística',
        'documentacao' => 'Documentação e placas',
        'posvenda'     => 'Indicadores e agendamentos (pós-venda)',
    ],

    /*
    | Áreas do sistema que podem ser liberadas para cada perfil (tela Perfis).
    | O perfil "admin" sempre tem tudo e não pode ser alterado.
    */
    'modulos' => [
        'Operação' => [
            'dashboard'          => 'Ver o dashboard de entregas',
            'veiculos.ver'       => 'Ver a lista e a ficha dos veículos',
            'veiculos.criar'     => 'Cadastrar veículos',
            'veiculos.excluir'   => 'Excluir veículos',
            'veiculos.vinculos'  => 'Trocar loja e vendedor do veículo',
            'consulta'           => 'Usar a consulta de vendedores, clientes e carros',
        ],
        'Planilhas e integrações' => [
            'planilhas.exportar' => 'Exportar planilhas',
            'planilhas.importar' => 'Importar planilhas',
            'glpi'               => 'Configurar o GLPI e gerenciar vendedores',
            'drive'              => 'Configurar e sincronizar o Google Drive',
        ],
        'Administração' => [
            'tokens'             => 'Gerenciar lojas e tokens de API',
            'usuarios'           => 'Gerenciar usuários e perfis',
        ],
    ],

    // Valores iniciais dos perfis criados na instalação (depois são editados pela tela)
    'perfis_iniciais' => [
        'entrega' => [
            'nome'     => 'Entrega',
            'descricao' => 'Equipe de entrega: atualiza documentação e placas.',
            'modulos'  => ['dashboard', 'veiculos.ver', 'consulta', 'planilhas.exportar'],
            'editar'   => ['documentacao'],
        ],
    ],

    // tipos: string | text | date | time | bool | int
    'campos' => [
        // Bloco principal
        'modelo'                     => ['header' => 'MODELO', 'label' => 'Modelo', 'tipo' => 'string', 'grupo' => 'principal'],
        'chassi'                     => ['header' => 'CHASSI', 'label' => 'Chassi', 'tipo' => 'string', 'grupo' => 'principal'],
        'modalidade'                 => ['header' => 'MODALIDADE', 'label' => 'Modalidade', 'tipo' => 'string', 'grupo' => 'principal'],
        'consultor'                  => ['header' => 'CONSULTOR', 'label' => 'Consultor (vendedor)', 'tipo' => 'string', 'grupo' => 'principal'],
        'cliente'                    => ['header' => 'CLIENTE', 'label' => 'Cliente', 'tipo' => 'string', 'grupo' => 'principal'],
        'nota_fiscal'                => ['header' => 'NOTA FISCAL', 'label' => 'Nota fiscal', 'tipo' => 'string', 'grupo' => 'principal'],
        'crm'                        => ['header' => 'CRM', 'label' => 'CRM', 'tipo' => 'string', 'grupo' => 'principal'],
        'campanha_bonus'             => ['header' => 'CAMPANHA / BÔNUS', 'label' => 'Campanha / bônus', 'tipo' => 'string', 'grupo' => 'principal'],
        'faturamento'                => ['header' => 'FATURAMENTO', 'label' => 'Faturamento', 'tipo' => 'date', 'grupo' => 'principal'],
        'emplacamento'               => ['header' => 'EMPLACAMENTO', 'label' => 'Emplacamento', 'tipo' => 'date', 'grupo' => 'principal'],

        // Acompanhamento / logística
        'data_solicitacao_carro'     => ['header' => 'DATA DA SOLICITAÇÃO DO CARRO', 'label' => 'Solicitação do carro', 'tipo' => 'date', 'grupo' => 'logistica'],
        'data_recebimento_documento' => ['header' => 'DATA RECEBIMENTO DO DOCUMENTO', 'label' => 'Recebimento do documento', 'tipo' => 'date', 'grupo' => 'logistica'],
        'entrega_documentacao'       => ['header' => 'ENTREGA DA DOCUMENTAÇÃO', 'label' => 'Entrega da documentação', 'tipo' => 'date', 'grupo' => 'logistica'],
        'status_emplacamento'        => ['header' => 'STATUS EMPLACAMENTO', 'label' => 'Status do emplacamento', 'tipo' => 'string', 'grupo' => 'logistica'],
        'prazo_emplacamento'         => ['header' => 'PRAZO EMPLACAMENTO', 'label' => 'Prazo do emplacamento', 'tipo' => 'date', 'grupo' => 'logistica'],
        'data_entrega'               => ['header' => 'DATA DE ENTREGA', 'label' => 'Data de entrega (previsão / real)', 'tipo' => 'date', 'grupo' => 'logistica'],
        'hora_entrega'               => ['header' => 'HORA DA ENTREGA', 'label' => 'Hora da entrega', 'tipo' => 'time', 'grupo' => 'logistica'],
        'vu'                         => ['header' => 'V.U.', 'label' => 'V.U.', 'tipo' => 'string', 'grupo' => 'logistica'],
        'entregue'                   => ['header' => 'ENTREGUE', 'label' => 'Entregue', 'tipo' => 'bool', 'grupo' => 'logistica'],
        'localizacao'                => ['header' => 'LOCALIZAÇÃO', 'label' => 'Localização', 'tipo' => 'string', 'grupo' => 'logistica'],

        // Documentação e placas  (cabeçalho mantido exatamente como na especificação homologada)
        'doc_emplacamento_consultor' => ['header' => 'DOC. EMPLACAMENTO ENTO CONSULTOR', 'label' => 'Doc. emplacamento entregue ao consultor', 'tipo' => 'string', 'grupo' => 'documentacao'],
        'entrega_despachante'        => ['header' => 'ENTREGA DESPACHANTE', 'label' => 'Entrega ao despachante', 'tipo' => 'date', 'grupo' => 'documentacao'],
        'status_placa'               => ['header' => 'STATUS PLACA', 'label' => 'Status da placa', 'tipo' => 'string', 'grupo' => 'documentacao'],
        'data_confeccao'             => ['header' => 'DATA CONFECÇÃO', 'label' => 'Data de confecção', 'tipo' => 'date', 'grupo' => 'documentacao'],
        'status_veiculo'             => ['header' => 'STATUS VEÍCULO', 'label' => 'Status do veículo', 'tipo' => 'string', 'grupo' => 'documentacao'],

        // Pós-venda
        'status_agendamento'         => ['header' => 'STATUS DE AGENDAMENTO', 'label' => 'Status do agendamento', 'tipo' => 'string', 'grupo' => 'posvenda'],
        'data_agendamento'           => ['header' => 'DATA DE AGENDAMENTO', 'label' => 'Data do agendamento', 'tipo' => 'date', 'grupo' => 'posvenda'],
        'hora_agendamento'           => ['header' => 'HORA DE AGENDAMENTO', 'label' => 'Hora do agendamento', 'tipo' => 'time', 'grupo' => 'posvenda'],
        'responsavel_agendamento'    => ['header' => 'RESPONSÁVEL PELO AGENDAMENTO', 'label' => 'Responsável pelo agendamento', 'tipo' => 'string', 'grupo' => 'posvenda'],
        'qualidade_entrega'          => ['header' => 'QUALIDADE DA ENTREGA', 'label' => 'Qualidade da entrega', 'tipo' => 'string', 'grupo' => 'posvenda'],
        'observacoes'                => ['header' => 'OBSERVAÇÕES', 'label' => 'Observações', 'tipo' => 'text', 'grupo' => 'posvenda'],
        'nps'                        => ['header' => 'NPS', 'label' => 'NPS (0 a 10)', 'tipo' => 'int', 'grupo' => 'posvenda'],
        'periodo_entrega'            => ['header' => 'PERÍODO DE ENTREGA', 'label' => 'Período de entrega', 'tipo' => 'string', 'grupo' => 'posvenda'],
    ],

    // Colunas aceitas além das homologadas (não obrigatórias)
    'opcionais' => [
        'placa' => ['header' => 'PLACA', 'label' => 'Placa', 'tipo' => 'string', 'grupo' => 'documentacao'],
    ],

    // Sugestões exibidas nos campos (o usuário pode digitar outro valor)
    'sugestoes' => [
        'modalidade'          => ['Varejo', 'Venda direta', 'Frotista', 'PCD'],
        'status_emplacamento' => ['Pendente', 'Em andamento', 'Emplacado'],
        'status_placa'        => ['Aguardando', 'Em confecção', 'Pronta', 'Instalada'],
        'status_veiculo'      => ['Em trânsito', 'No estoque', 'Em preparação', 'Pronto para entrega', 'Entregue'],
        'status_agendamento'  => ['Não agendado', 'Agendado', 'Reagendado', 'Concluído'],
        'qualidade_entrega'   => ['Ótima', 'Boa', 'Regular', 'Ruim'],
        'periodo_entrega'     => ['Manhã', 'Tarde', 'Noite'],
        'doc_emplacamento_consultor' => ['Sim', 'Não'],
    ],
];
