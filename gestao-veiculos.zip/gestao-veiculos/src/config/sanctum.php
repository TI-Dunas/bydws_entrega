<?php

return [
    // API usa somente tokens Bearer (sem sessão/cookie)
    'stateful' => [],
    'guard' => [],
    'expiration' => null,
    'token_prefix' => env('SANCTUM_TOKEN_PREFIX', 'veic_'),
    'middleware' => [
        'authenticate_session' => Laravel\Sanctum\Http\Middleware\AuthenticateSession::class,
        'encrypt_cookies' => Illuminate\Cookie\Middleware\EncryptCookies::class,
        'validate_csrf_token' => Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class,
    ],
];
