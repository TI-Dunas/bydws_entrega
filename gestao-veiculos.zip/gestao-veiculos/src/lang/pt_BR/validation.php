<?php

$atributos = [];
foreach (config('veiculos.campos', []) + config('veiculos.opcionais', []) as $campo => $def) {
    $atributos[$campo] = mb_strtolower($def['label']);
}

return [
    'required'    => 'O campo :attribute é obrigatório.',
    'email'       => 'Informe um e-mail válido em :attribute.',
    'unique'      => 'Já existe um registro com este :attribute.',
    'exists'      => 'O valor escolhido em :attribute não existe.',
    'file'        => 'Envie um arquivo em :attribute.',
    'mimes'       => 'O arquivo em :attribute precisa ser do tipo :values.',
    'url'         => 'Informe um endereço válido em :attribute.',
    'date'        => 'Informe uma data válida em :attribute.',
    'date_format' => 'Use o formato :format em :attribute.',
    'boolean'     => 'O campo :attribute aceita apenas sim ou não.',
    'integer'     => 'O campo :attribute precisa ser um número inteiro.',
    'string'      => 'O campo :attribute precisa ser um texto.',
    'in'          => 'O valor escolhido em :attribute não é válido.',
    'between'     => ['numeric' => 'O campo :attribute precisa estar entre :min e :max.'],
    'max'         => ['string' => 'O campo :attribute aceita até :max caracteres.', 'file' => 'O arquivo em :attribute pode ter até :max KB.', 'numeric' => 'O campo :attribute não pode ser maior que :max.'],
    'min'         => ['string' => 'O campo :attribute precisa ter ao menos :min caracteres.', 'numeric' => 'O campo :attribute não pode ser menor que :min.'],
    'attributes'  => $atributos + [
        'name' => 'nome', 'password' => 'senha', 'loja_id' => 'loja', 'vendedor_id' => 'vendedor',
        'arquivo' => 'arquivo', 'url' => 'URL do GLPI', 'ou' => 'OU', 'codigo' => 'código', 'credencial' => 'credencial',
    ],
];
