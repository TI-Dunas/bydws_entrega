<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ConsultaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GlpiController;
use App\Http\Controllers\GoogleDriveController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\PlanilhaController;
use App\Http\Controllers\TokenController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\VeiculoController;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'form'])->name('login');
    Route::post('/login', [LoginController::class, 'entrar'])->middleware('throttle:10,1');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [LoginController::class, 'sair'])->name('logout');

    // Página inicial: dashboard ou a primeira área liberada
    Route::get('/', function () {
        $u = auth()->user();
        foreach (['dashboard' => 'dashboard', 'veiculos.ver' => 'veiculos.index', 'consulta' => 'consulta',
                  'planilhas.importar' => 'planilhas.index', 'planilhas.exportar' => 'planilhas.index', 'glpi' => 'glpi.index',
                  'drive' => 'drive.index', 'tokens' => 'tokens.index', 'usuarios' => 'usuarios.index'] as $m => $rota) {
            if ($u->pode($m)) {
                return redirect()->route($rota);
            }
        }
        return response()->view('sem_acesso', [], 403);
    })->name('inicio');

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('pode:dashboard');
    Route::get('/consulta', [ConsultaController::class, 'index'])->name('consulta')->middleware('pode:consulta');

    Route::middleware('pode:veiculos.ver')->group(function () {
        Route::get('/veiculos', [VeiculoController::class, 'index'])->name('veiculos.index');
        Route::get('/veiculos/{veiculo}/editar', [VeiculoController::class, 'edit'])->name('veiculos.edit')->whereNumber('veiculo');
        Route::put('/veiculos/{veiculo}', [VeiculoController::class, 'update'])->name('veiculos.update')->whereNumber('veiculo');
    });
    Route::middleware('pode:veiculos.criar')->group(function () {
        Route::get('/veiculos/novo', [VeiculoController::class, 'create'])->name('veiculos.create');
        Route::post('/veiculos', [VeiculoController::class, 'store'])->name('veiculos.store');
    });
    Route::delete('/veiculos/{veiculo}', [VeiculoController::class, 'destroy'])->name('veiculos.destroy')->middleware('pode:veiculos.excluir');

    Route::get('/planilhas', [PlanilhaController::class, 'index'])->name('planilhas.index')->middleware('pode:planilhas.importar,planilhas.exportar');
    Route::get('/planilhas/exportar', [PlanilhaController::class, 'exportar'])->name('planilhas.exportar')->middleware('pode:planilhas.exportar');
    Route::middleware('pode:planilhas.importar')->group(function () {
        Route::post('/planilhas/importar', [PlanilhaController::class, 'importar'])->name('planilhas.importar');
        Route::get('/planilhas/modelo', [PlanilhaController::class, 'modelo'])->name('planilhas.modelo');
    });

    Route::middleware('pode:glpi')->group(function () {
        Route::get('/glpi', [GlpiController::class, 'index'])->name('glpi.index');
        Route::post('/glpi/config', [GlpiController::class, 'salvar'])->name('glpi.salvar');
        Route::post('/glpi/testar', [GlpiController::class, 'testar'])->name('glpi.testar');
        Route::post('/glpi/sincronizar', [GlpiController::class, 'sincronizar'])->name('glpi.sincronizar');
        Route::post('/vendedores', [GlpiController::class, 'criarVendedor'])->name('vendedores.store');
        Route::put('/vendedores/{vendedor}', [GlpiController::class, 'atualizarVendedor'])->name('vendedores.update');
    });

    Route::middleware('pode:drive')->group(function () {
        Route::get('/drive', [GoogleDriveController::class, 'index'])->name('drive.index');
        Route::post('/drive/config', [GoogleDriveController::class, 'salvar'])->name('drive.salvar');
        Route::post('/drive/enviar-planilha', [GoogleDriveController::class, 'enviarPlanilha'])->name('drive.enviarPlanilha');
        Route::post('/drive/enviar-arquivo', [GoogleDriveController::class, 'enviarArquivo'])->name('drive.enviarArquivo');
        Route::post('/drive/importar-planilha', [GoogleDriveController::class, 'importarPlanilha'])->name('drive.importarPlanilha');
        Route::post('/drive/importar/{arquivoId}', [GoogleDriveController::class, 'importarArquivo'])->name('drive.importarArquivo');
    });

    Route::middleware('pode:tokens')->group(function () {
        Route::get('/tokens', [TokenController::class, 'index'])->name('tokens.index');
        Route::post('/lojas', [TokenController::class, 'criarLoja'])->name('lojas.store');
        Route::post('/tokens', [TokenController::class, 'gerar'])->name('tokens.gerar');
        Route::delete('/tokens/{id}', [TokenController::class, 'revogar'])->name('tokens.revogar');
    });

    Route::middleware('pode:usuarios')->group(function () {
        Route::get('/usuarios', [UsuarioController::class, 'index'])->name('usuarios.index');
        Route::post('/usuarios', [UsuarioController::class, 'store'])->name('usuarios.store');
        Route::put('/usuarios/{usuario}', [UsuarioController::class, 'update'])->name('usuarios.update');
        Route::delete('/usuarios/{usuario}', [UsuarioController::class, 'destroy'])->name('usuarios.destroy');

        Route::get('/perfis', [PerfilController::class, 'index'])->name('perfis.index');
        Route::get('/perfis/novo', [PerfilController::class, 'create'])->name('perfis.create');
        Route::post('/perfis', [PerfilController::class, 'store'])->name('perfis.store');
        Route::get('/perfis/{perfil}/editar', [PerfilController::class, 'edit'])->name('perfis.edit');
        Route::put('/perfis/{perfil}', [PerfilController::class, 'update'])->name('perfis.update');
        Route::delete('/perfis/{perfil}', [PerfilController::class, 'destroy'])->name('perfis.destroy');
    });
});
