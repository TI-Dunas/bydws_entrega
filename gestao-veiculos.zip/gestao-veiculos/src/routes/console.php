<?php

use App\Models\Setting;
use App\Models\SyncLog;
use App\Models\Veiculo;
use App\Services\GlpiService;
use App\Services\GoogleDriveService;
use App\Services\PlanilhaService;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('glpi:sincronizar', function (GlpiService $glpi) {
    try {
        $r = $glpi->sincronizarVendedores();
        $msg = "{$r['total']} usuários na OU: {$r['novos']} novos, {$r['atualizados']} atualizados, {$r['inativados']} inativados.";
        SyncLog::registrar('glpi', 'Sincronização automática', true, $msg);
        $this->info($msg);
    } catch (\Throwable $e) {
        SyncLog::registrar('glpi', 'Sincronização automática', false, $e->getMessage());
        $this->error($e->getMessage());
    }
})->purpose('Sincroniza vendedores (usuários GLPI da OU configurada)');

Artisan::command('drive:sincronizar', function (GoogleDriveService $drive, PlanilhaService $planilhas) {
    try {
        $lojaId = Setting::get('drive.loja_id');
        $n = $drive->escreverPlanilha($planilhas->linhasExportacao(Veiculo::query()->daLoja($lojaId ? (int) $lojaId : null)));
        SyncLog::registrar('drive', 'Atualização automática da planilha', true, "{$n} veículos enviados.");
        $this->info("{$n} veículos enviados.");
    } catch (\Throwable $e) {
        SyncLog::registrar('drive', 'Atualização automática da planilha', false, $e->getMessage());
        $this->error($e->getMessage());
    }
})->purpose('Atualiza a planilha Google com os veículos do sistema');

Schedule::command('glpi:sincronizar')->hourly()->withoutOverlapping()
    ->when(fn () => Setting::get('glpi.auto') === '1');

Schedule::command('drive:sincronizar')->everyThirtyMinutes()->withoutOverlapping()
    ->when(fn () => Setting::get('drive.auto') === '1');
