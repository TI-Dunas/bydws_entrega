<?php

use App\Http\Controllers\Api\ConsultaApiController;
use App\Http\Controllers\Api\PlanilhaApiController;
use Illuminate\Support\Facades\Route;

// Todas as rotas exigem: Authorization: Bearer <TOKEN>
Route::middleware(['auth:sanctum', 'throttle:120,1'])->group(function () {
    Route::middleware('ability:read,write')->group(function () {
        Route::get('/vendedores', [ConsultaApiController::class, 'vendedores']);
        Route::get('/clientes', [ConsultaApiController::class, 'clientes']);
        Route::get('/carros', [ConsultaApiController::class, 'carros']);
        Route::get('/veiculos/exportar', [PlanilhaApiController::class, 'exportar']);
    });
    Route::post('/veiculos/importar', [PlanilhaApiController::class, 'importar'])->middleware('abilities:write');
});
