@extends('layouts.app')
@section('titulo', 'Usuários')
@section('conteudo')
<div class="topo"><div><h1>Usuários</h1><p>O que cada usuário vê e edita vem do perfil. <a href="{{ route('perfis.index') }}">Personalizar perfis</a></p></div></div>

<form class="bloco" method="post" action="{{ route('usuarios.store') }}">
  @csrf
  <h2>Criar usuário</h2>
  <div class="campos">
    <div><label for="u_nome">Nome</label><input id="u_nome" name="name" value="{{ old('name') }}" required></div>
    <div><label for="u_email">E-mail</label><input type="email" id="u_email" name="email" value="{{ old('email') }}" required></div>
    <div><label for="u_senha">Senha inicial</label><input type="password" id="u_senha" name="password" minlength="8" required autocomplete="new-password"></div>
    <div><label for="u_perfil">Perfil</label><select id="u_perfil" name="perfil">
      @foreach($perfis as $p)<option value="{{ $p->slug }}" @selected(old('perfil', 'entrega') === $p->slug)>{{ $p->nome }}</option>@endforeach</select></div>
    <div><label for="u_loja">Loja</label><select id="u_loja" name="loja_id"><option value="">Todas as lojas</option>
      @foreach($lojas as $l)<option value="{{ $l->id }}">{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
  </div>
  <div class="acoes" style="margin-top:1rem"><button class="botao" type="submit">Criar usuário</button></div>
</form>

<section class="bloco">
  <h2>Usuários cadastrados</h2>
  <div class="tabela"><table>
    <thead><tr><th>Nome</th><th>E-mail</th><th>Perfil, loja e senha</th><th></th></tr></thead>
    <tbody>
    @foreach($usuarios as $u)
      <tr>
        <td>{{ $u->name }}</td>
        <td>{{ $u->email }}</td>
        <td>
          <form method="post" action="{{ route('usuarios.update', $u) }}" class="acoes" style="flex-wrap:nowrap">
            @csrf @method('put')
            <select name="perfil" aria-label="Perfil de {{ $u->name }}" style="min-width:140px">
              @foreach($perfis as $p)<option value="{{ $p->slug }}" @selected($u->perfil === $p->slug)>{{ $p->nome }}</option>@endforeach</select>
            <select name="loja_id" aria-label="Loja de {{ $u->name }}" style="min-width:130px"><option value="">Todas</option>
              @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($u->loja_id == $l->id)>{{ $l->codigo }}</option>@endforeach</select>
            <input type="password" name="password" placeholder="Nova senha" minlength="8" aria-label="Nova senha de {{ $u->name }}" autocomplete="new-password" style="min-width:130px">
            <button class="botao pequeno secundario" type="submit">Salvar</button>
          </form>
        </td>
        <td>@unless($u->is(auth()->user()))
          <form method="post" action="{{ route('usuarios.destroy', $u) }}" onsubmit="return confirm('Excluir {{ addslashes($u->name) }}?')">@csrf @method('delete')
            <button class="botao pequeno perigo" type="submit">Excluir</button></form>
        @endunless</td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
</section>
@endsection
