@extends('layouts.app')
@section('titulo', 'Perfis')
@section('conteudo')
<div class="topo">
  <div><h1>Perfis</h1><p>Defina o que cada perfil acessa e quais campos dos veículos ele vê ou edita.</p></div>
  <a class="botao" href="{{ route('perfis.create') }}">Criar perfil</a>
</div>

<section class="bloco">
  <div class="tabela"><table>
    <thead><tr><th>Perfil</th><th>Áreas liberadas</th><th>Campos editáveis</th><th class="num">Usuários</th><th></th></tr></thead>
    <tbody>
    @foreach($perfis as $p)
      @php
        $total = count(\App\Models\Perfil::todosCampos());
        $editaveis = $p->ehAdmin() ? $total : count(array_filter($p->campos ?? [], fn ($n) => $n === 'editar'));
        $ocultos = $p->ehAdmin() ? 0 : count(array_filter($p->campos ?? [], fn ($n) => $n === 'oculto'));
        $areas = $p->ehAdmin() ? count(\App\Models\Perfil::todosModulos()) : count($p->modulos ?? []);
      @endphp
      <tr>
        <td><strong>{{ $p->nome }}</strong>@if($p->sistema) <span class="selo alerta">Fixo</span>@endif
          @if($p->descricao)<div class="dica" style="margin:0">{{ $p->descricao }}</div>@endif</td>
        <td>{{ $areas }} de {{ count(\App\Models\Perfil::todosModulos()) }}</td>
        <td>{{ $editaveis }} de {{ $total }}@if($ocultos) <span class="selo">{{ $ocultos }} ocultos</span>@endif</td>
        <td class="num">{{ $p->usuarios_count }}</td>
        <td><div class="acoes" style="justify-content:flex-end">
          @unless($p->sistema)<a class="botao pequeno secundario" href="{{ route('perfis.edit', $p) }}">Editar</a>@endunless
          <a class="botao pequeno secundario" href="{{ route('perfis.create', ['base' => $p->slug]) }}">Duplicar</a>
          @unless($p->sistema)
            <form method="post" action="{{ route('perfis.destroy', $p) }}" onsubmit="return confirm('Excluir o perfil {{ addslashes($p->nome) }}?')">@csrf @method('delete')
              <button class="botao pequeno perigo" type="submit">Excluir</button></form>
          @endunless
        </div></td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
</section>
@endsection
