@extends('layouts.app')
@section('titulo', $perfil->exists ? 'Perfil '.$perfil->nome : 'Criar perfil')
@section('estilo')
.modulos{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.25rem}
.modulos fieldset{border:0;padding:0;margin:0}
.modulos legend{font-family:var(--titulo);font-weight:600;margin-bottom:.4rem}
.modulos .marcar{margin-bottom:.35rem}
.matriz td:first-child{width:45%}
.niveis{display:inline-flex;border:1px solid var(--linha);border-radius:var(--raio);overflow:hidden}
.niveis label{margin:0;cursor:pointer;font-weight:500;color:var(--suave);font-size:.85rem}
.niveis input{position:absolute;opacity:0;width:1px;height:1px}
.niveis span{display:block;padding:.3rem .75rem;border-left:1px solid var(--linha)}
.niveis label:first-child span{border-left:0}
.niveis input:focus-visible+span{outline:2px solid var(--mercosul);outline-offset:-2px}
.niveis input[value=oculto]:checked+span{background:var(--papel);color:var(--tinta)}
.niveis input[value=ler]:checked+span{background:var(--mercosul-fundo);color:var(--mercosul)}
.niveis input[value=editar]:checked+span{background:var(--ok-fundo);color:var(--ok)}
.bloco-cab{display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;margin-bottom:.5rem}
.bloco-cab h2{margin:0}
.salvar{position:sticky;bottom:0;background:var(--papel);padding:.9rem 0;border-top:1px solid var(--linha);display:flex;gap:.75rem;align-items:center}
@endsection
@section('conteudo')
@php
  $defs = \App\Models\Perfil::todosCampos();
  $mods = old('modulos', $perfil->modulos ?? []);
@endphp
<div class="topo">
  <div><h1>{{ $perfil->exists ? 'Editar perfil '.$perfil->nome : 'Criar perfil' }}</h1>
    <p>As mudanças valem no próximo clique dos usuários com este perfil.</p></div>
  <a class="botao secundario" href="{{ route('perfis.index') }}">Voltar para perfis</a>
</div>

<form method="post" action="{{ $perfil->exists ? route('perfis.update', $perfil) : route('perfis.store') }}">
  @csrf
  @if($perfil->exists) @method('put') @endif

  <section class="bloco">
    <div class="campos">
      <div><label for="nome">Nome do perfil</label><input id="nome" name="nome" value="{{ old('nome', $perfil->nome) }}" maxlength="80" required></div>
      <div style="grid-column:span 2"><label for="descricao">Descrição</label><input id="descricao" name="descricao" value="{{ old('descricao', $perfil->descricao) }}" maxlength="255" placeholder="Para que serve este perfil"></div>
    </div>
  </section>

  <section class="bloco">
    <h2>Áreas do sistema</h2>
    <div class="modulos">
      @foreach(config('veiculos.modulos') as $grupo => $itens)
        <fieldset><legend>{{ $grupo }}</legend>
          @foreach($itens as $k => $r)
            <label class="marcar"><input type="checkbox" name="modulos[]" value="{{ $k }}" @checked(in_array($k, $mods, true))> {{ $r }}</label>
          @endforeach
        </fieldset>
      @endforeach
    </div>
    <p class="dica">Quem edita algum campo ou cadastra veículos recebe automaticamente acesso à lista de veículos.</p>
  </section>

  @foreach(config('veiculos.grupos') as $g => $titulo)
  <section class="bloco" data-grupo="{{ $g }}">
    <div class="bloco-cab">
      <h2>{{ $titulo }}</h2>
      <div class="acoes" aria-label="Aplicar a todo o bloco {{ $titulo }}">
        <span class="dica" style="margin:0">Todo o bloco:</span>
        @foreach(\App\Models\Perfil::NIVEIS as $n => $r)
          <button type="button" class="botao pequeno secundario" data-aplicar="{{ $n }}">{{ $r }}</button>
        @endforeach
      </div>
    </div>
    <div class="tabela"><table class="matriz"><tbody>
      @foreach($defs as $c => $def)
        @continue($def['grupo'] !== $g)
        @php $atual = old('campos.'.$c, $perfil->campos[$c] ?? 'ler'); @endphp
        <tr>
          <td>{{ $def['label'] }}</td>
          <td>
            <div class="niveis" role="radiogroup" aria-label="{{ $def['label'] }}">
              @foreach(\App\Models\Perfil::NIVEIS as $n => $r)
                @continue($c === 'chassi' && $n === 'oculto')
                <label><input type="radio" name="campos[{{ $c }}]" value="{{ $n }}" @checked($atual === $n)><span>{{ $r }}</span></label>
              @endforeach
            </div>
          </td>
        </tr>
      @endforeach
    </tbody></table></div>
  </section>
  @endforeach

  <div class="salvar">
    <button class="botao" type="submit">{{ $perfil->exists ? 'Salvar perfil' : 'Criar perfil' }}</button>
    <span class="dica" style="margin:0">Oculto: o campo não aparece. Leitura: aparece sem edição. Edição: pode alterar.</span>
  </div>
</form>
@endsection

@push('scripts')
<script>
document.querySelectorAll('[data-aplicar]').forEach(function (b) {
  b.addEventListener('click', function () {
    var bloco = b.closest('[data-grupo]');
    bloco.querySelectorAll('input[type=radio][value="' + b.dataset.aplicar + '"]').forEach(function (r) { r.checked = true; });
  });
});
</script>
@endpush
