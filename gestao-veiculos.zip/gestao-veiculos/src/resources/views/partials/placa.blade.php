@if($placa ?? null)
<span class="placa {{ $classe ?? '' }}" title="Placa {{ $placa }}"><span>{{ $placa }}</span></span>
@else
<span class="placa sem {{ $classe ?? '' }}"><span>sem placa</span></span>
@endif
