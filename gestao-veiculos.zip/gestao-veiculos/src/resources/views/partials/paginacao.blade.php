@if($p->hasPages())
<nav class="paginacao" aria-label="Paginação">
  @if(!$p->onFirstPage())<a href="{{ $p->previousPageUrl() }}">Anterior</a>@endif
  <span class="atual">Página {{ $p->currentPage() }} de {{ $p->lastPage() }}</span>
  @if($p->hasMorePages())<a href="{{ $p->nextPageUrl() }}">Próxima</a>@endif
  <span style="border:0;background:none;color:var(--suave)">{{ $p->total() }} registros</span>
</nav>
@endif
