<section class="bloco">
  <h2>Histórico recente</h2>
  @if($logs->isEmpty())
    <p class="vazio">Nenhuma operação registrada ainda.</p>
  @else
  <div class="tabela"><table>
    <thead><tr><th>Quando</th><th>Ação</th><th>Resultado</th><th>Detalhes</th></tr></thead>
    <tbody>
    @foreach($logs as $l)
      <tr>
        <td style="white-space:nowrap">{{ $l->created_at->format('d/m/Y H:i') }}</td>
        <td>{{ $l->acao }}</td>
        <td><span class="selo {{ $l->status === 'ok' ? 'ok' : 'erro' }}">{{ $l->status === 'ok' ? 'Concluído' : 'Falhou' }}</span></td>
        <td style="max-width:520px">{{ \Illuminate\Support\Str::limit($l->mensagem, 220) }}</td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
  @endif
</section>
