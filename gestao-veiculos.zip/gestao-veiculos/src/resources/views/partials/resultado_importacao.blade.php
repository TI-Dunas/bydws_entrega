@if($resultado)
  @if($resultado['ok'])
    <div class="aviso ok" role="status">
      Importação concluída: {{ $resultado['criados'] }} veículos criados e {{ $resultado['atualizados'] }} atualizados.
      @if($resultado['avisos'])
        <details style="margin-top:.4rem"><summary>{{ count($resultado['avisos']) }} avisos</summary>
          <ul>@foreach(array_slice($resultado['avisos'], 0, 100) as $a)<li>{{ $a }}</li>@endforeach</ul>
        </details>
      @endif
    </div>
  @else
    <div class="aviso erro" role="alert">A planilha não foi importada porque não segue o layout homologado:
      <ul>@foreach($resultado['erros'] as $e)<li>{{ $e }}</li>@endforeach</ul>
    </div>
  @endif
@endif
