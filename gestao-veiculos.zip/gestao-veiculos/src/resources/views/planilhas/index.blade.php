@extends('layouts.app')
@section('titulo', 'Importar e exportar')
@section('conteudo')
<div class="topo"><div><h1>Importar e exportar planilhas</h1><p>Arquivos .xlsx com o layout homologado. Linhas com chassi já cadastrado são atualizadas.</p></div></div>

@include('partials.resultado_importacao', ['resultado' => $resultado])

<div class="grade g2">
  @if(auth()->user()->pode('planilhas.importar'))
  <form class="bloco" method="post" action="{{ route('planilhas.importar') }}" enctype="multipart/form-data">
    @csrf
    <h2>Importar planilha</h2>
    <div class="campos" style="grid-template-columns:1fr">
      <div><label for="arquivo">Arquivo .xlsx</label><input type="file" id="arquivo" name="arquivo" accept=".xlsx,.xls" required></div>
      <div><label for="loja_id">Loja de destino</label>
        <select id="loja_id" name="loja_id" required>@foreach($lojas as $l)<option value="{{ $l->id }}" @selected(old('loja_id') == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
      <div><label for="vendedor_id">Vendedor para todos os registros (opcional)</label>
        <select id="vendedor_id" name="vendedor_id">
          <option value="">Usar a coluna CONSULTOR de cada linha</option>
          @foreach($vendedores as $v)<option value="{{ $v->id }}">{{ $v->nome }}</option>@endforeach
        </select>
        <p class="dica">Sem vendedor escolhido, o sistema vincula pelo nome exato do consultor.</p></div>
    </div>
    <div class="acoes" style="margin-top:1rem"><button class="botao" type="submit">Importar planilha</button></div>
  </form>
  @endif

  @if(auth()->user()->pode('planilhas.exportar'))
  <section class="bloco">
    <h2>Exportar</h2>
    <form class="filtros" method="get" action="{{ route('planilhas.exportar') }}">
      <div><label for="e_loja">Loja</label><select id="e_loja" name="loja_id"><option value="">Todas</option>
        @foreach($lojas as $l)<option value="{{ $l->id }}">{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
      <div><label for="e_ini">Entrega de</label><input type="date" id="e_ini" name="inicio"></div>
      <div><label for="e_fim">até</label><input type="date" id="e_fim" name="fim"></div>
      <div style="flex:0 0 auto"><button class="botao secundario" type="submit">Baixar .xlsx</button></div>
    </form>
    @if(auth()->user()->pode('planilhas.importar'))<p class="dica" style="margin-top:1rem">Precisa de um arquivo em branco? <a href="{{ route('planilhas.modelo') }}">Baixe o modelo com os cabeçalhos homologados</a>.</p>@endif
    @if(auth()->user()->pode('drive'))<p class="dica">Para Google Sheets, use a aba <a href="{{ route('drive.index') }}">Google Drive</a>.</p>@endif
  </section>
  @endif
</div>

@if(auth()->user()->pode('planilhas.importar'))
<section class="bloco">
  <h2>Layout homologado ({{ count($cabecalhos) }} colunas obrigatórias)</h2>
  <p class="dica" style="margin:0 0 .75rem">Os cabeçalhos precisam ser idênticos, incluindo acentos e pontuação; a ordem das colunas é livre. A coluna PLACA é aceita como opcional.</p>
  <div style="display:flex;flex-wrap:wrap;gap:.4rem">@foreach($cabecalhos as $h)<span class="selo">{{ $h }}</span>@endforeach</div>
</section>

@include('partials.logs')
@endif
@endsection
