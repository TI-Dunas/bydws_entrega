@extends('layouts.app')
@section('titulo', 'Google Drive')
@section('conteudo')
<div class="topo"><div><h1>Sincronização com o Google Drive</h1><p>Envie e receba a planilha operacional via Google Sheets ou arquivos .xlsx na pasta compartilhada.</p></div></div>

@include('partials.resultado_importacao', ['resultado' => $resultado])

@if($email)
  <div class="aviso info">Compartilhe a pasta e a planilha como <strong>Editor</strong> com a conta de serviço <code>{{ $email }}</code>.
    Para enviar arquivos .xlsx, use uma pasta dentro de um Drive compartilhado: contas de serviço não têm cota própria de armazenamento.</div>
@endif

<div class="grade g2">
<form class="bloco" method="post" action="{{ route('drive.salvar') }}" enctype="multipart/form-data">
  @csrf
  <h2>Configuração</h2>
  <div class="campos" style="grid-template-columns:1fr">
    <div><label for="credencial">Credencial da conta de serviço (.json)</label><input type="file" id="credencial" name="credencial" accept=".json,application/json">
      <p class="dica">{{ $email ? 'Credencial salva. Envie outra só para trocar.' : 'Crie no Google Cloud com as APIs Drive e Sheets ativadas.' }}</p></div>
    <div><label for="pasta_id">Pasta do Drive (ID ou link)</label><input id="pasta_id" name="pasta_id" value="{{ $cfg['pasta_id'] }}"></div>
    <div><label for="planilha_id">Planilha Google (ID ou link)</label><input id="planilha_id" name="planilha_id" value="{{ $cfg['planilha_id'] }}"></div>
    <div><label for="aba">Aba da planilha</label><input id="aba" name="aba" value="{{ $cfg['aba'] }}" required></div>
    <div><label for="loja_id">Loja usada na sincronização</label>
      <select id="loja_id" name="loja_id"><option value="">Todas (somente envio)</option>
        @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($cfg['loja_id'] == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select>
      <p class="dica">Importações do Drive entram nesta loja; o envio exporta só os veículos dela.</p></div>
    <label class="marcar"><input type="checkbox" name="auto" value="1" @checked($cfg['auto'] === '1')> Atualizar a planilha Google automaticamente a cada 30 minutos</label>
  </div>
  <div class="acoes" style="margin-top:1rem"><button class="botao" type="submit">Salvar configuração</button></div>
</form>

<section class="bloco">
  <h2>Sincronizar agora</h2>
  <div style="display:grid;gap:1rem">
    <form method="post" action="{{ route('drive.enviarPlanilha') }}">@csrf
      <button class="botao" type="submit">Atualizar planilha Google</button>
      <p class="dica">Substitui o conteúdo da aba “{{ $cfg['aba'] }}” pelos dados do sistema.</p></form>
    <form method="post" action="{{ route('drive.importarPlanilha') }}" onsubmit="return confirm('Importar a planilha Google para o sistema? Veículos com o mesmo chassi serão atualizados.')">@csrf
      <button class="botao secundario" type="submit">Importar da planilha Google</button>
      <p class="dica">Lê a aba “{{ $cfg['aba'] }}” e aplica a mesma validação de cabeçalhos da importação de arquivos.</p></form>
    <form method="post" action="{{ route('drive.enviarArquivo') }}">@csrf
      <button class="botao secundario" type="submit">Enviar .xlsx para a pasta</button>
      <p class="dica">Cria um arquivo com data e hora no nome, útil como cópia de segurança.</p></form>
  </div>
</section>
</div>

<section class="bloco">
  <h2>Arquivos na pasta</h2>
  @if($erroLista)
    <div class="aviso erro">Não foi possível listar a pasta: {{ $erroLista }}</div>
  @elseif(empty($arquivos))
    <p class="vazio">{{ $cfg['pasta_id'] ? 'A pasta está vazia ou não foi compartilhada com a conta de serviço.' : 'Informe a pasta do Drive na configuração para ver os arquivos.' }}</p>
  @else
  <div class="tabela"><table>
    <thead><tr><th>Arquivo</th><th>Tipo</th><th>Modificado</th><th></th></tr></thead>
    <tbody>
    @foreach($arquivos as $a)
      @php($importavel = in_array($a['tipo'], ['application/vnd.google-apps.spreadsheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'], true))
      <tr>
        <td>@if($a['link'])<a href="{{ $a['link'] }}" target="_blank" rel="noopener">{{ $a['nome'] }}</a>@else{{ $a['nome'] }}@endif</td>
        <td>{{ $a['tipo'] === 'application/vnd.google-apps.spreadsheet' ? 'Google Sheets' : ($importavel ? 'Excel' : 'Outro') }}</td>
        <td>{{ $a['modificado'] ? \Carbon\Carbon::parse($a['modificado'])->timezone(config('app.timezone'))->format('d/m/Y H:i') : '—' }}</td>
        <td>@if($importavel)
          <form method="post" action="{{ route('drive.importarArquivo', $a['id']) }}" onsubmit="return confirm('Importar {{ addslashes($a['nome']) }}?')">@csrf
            <button class="botao pequeno secundario" type="submit">Importar</button></form>
        @endif</td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
  @endif
</section>

@include('partials.logs')
@endsection
