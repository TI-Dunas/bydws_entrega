@extends('layouts.app')
@section('titulo', 'Veículos')
@section('conteudo')
@php($sugPlaca = config('veiculos.sugestoes.status_placa'))
@php($u = auth()->user())
<div class="topo">
  <div><h1>Veículos</h1><p>{{ count($u->camposEditaveis()) ? 'Você pode editar '.count($u->camposEditaveis()).' campos, conforme o perfil '.($u->perfilRel?->nome ?? $u->perfil).'.' : 'Seu perfil permite apenas consultar.' }}</p></div>
  <div class="acoes">
    @if($u->pode('planilhas.exportar'))<a class="botao secundario" href="{{ route('planilhas.exportar', ['loja_id' => $lojaId]) }}">Exportar (.xlsx)</a>@endif
    @if($u->pode('veiculos.criar'))<a class="botao" href="{{ route('veiculos.create') }}">Cadastrar veículo</a>@endif
  </div>
</div>

<form class="bloco filtros" method="get">
  <div style="flex:2 1 260px"><label for="busca">Buscar</label><input id="busca" name="busca" value="{{ request('busca') }}" placeholder="Chassi, placa, modelo, cliente ou consultor"></div>
  @if($lojas->isNotEmpty())
  <div><label for="loja_id">Loja</label><select id="loja_id" name="loja_id"><option value="">Todas</option>
    @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($lojaId == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
  @endif
  <div><label for="entregue">Entrega</label><select id="entregue" name="entregue"><option value="">Todas</option>
    <option value="0" @selected(request('entregue') === '0')>A entregar</option><option value="1" @selected(request('entregue') === '1')>Entregues</option></select></div>
  <div><label for="status_placa">Status da placa</label><select id="status_placa" name="status_placa"><option value="">Todos</option>
    @foreach($sugPlaca as $s)<option @selected(request('status_placa') === $s)>{{ $s }}</option>@endforeach</select></div>
  <div style="flex:0 0 auto"><button class="botao" type="submit">Filtrar</button></div>
</form>

<section class="bloco">
  @if($veiculos->isEmpty())
    <p class="vazio">Nenhum veículo encontrado. @if($u->pode('planilhas.importar'))Importe uma planilha em <a href="{{ route('planilhas.index') }}">Importar e exportar</a>.@endif</p>
  @else
  <div class="tabela"><table>
    <thead><tr>@if($u->veCampo('placa'))<th>Placa</th>@endif @if($u->veCampo('modelo'))<th>Modelo</th>@endif<th>Chassi</th>@if($u->veCampo('cliente'))<th>Cliente</th>@endif @if($u->veCampo('consultor'))<th>Consultor</th>@endif @if($u->veCampo('data_entrega'))<th>Entrega</th>@endif @if($u->veCampo('status_placa'))<th>Placa (status)</th>@endif @if($u->veCampo('entregue'))<th>Situação</th>@endif<th></th></tr></thead>
    <tbody>
    @foreach($veiculos as $v)
      <tr>
        @if($u->veCampo('placa'))<td>@include('partials.placa', ['placa' => $v->placa])</td>@endif
        @if($u->veCampo('modelo'))<td>{{ $v->modelo }}</td>@endif
        <td class="mono">{{ $v->chassi }}</td>
        @if($u->veCampo('cliente'))<td>{{ $v->cliente }}</td>@endif
        @if($u->veCampo('consultor'))<td>{{ $v->vendedor?->nome ?? $v->consultor }}</td>@endif
        @if($u->veCampo('data_entrega'))<td style="white-space:nowrap">{{ $v->data_entrega?->format('d/m/Y') ?? '—' }} {{ $v->hora_entrega && $u->veCampo('hora_entrega') ? substr($v->hora_entrega, 0, 5) : '' }}</td>@endif
        @if($u->veCampo('status_placa'))<td>{{ $v->status_placa ?: '—' }}</td>@endif
        @if($u->veCampo('entregue'))<td>
          @if($v->entregue)<span class="selo ok">Entregue</span>
          @elseif($v->data_entrega && $v->data_entrega->lt(now()->startOfDay()))<span class="selo erro">Data vencida</span>
          @else<span class="selo azul">A entregar</span>@endif
        </td>@endif
        <td><a class="botao pequeno secundario" href="{{ route('veiculos.edit', $v) }}">Abrir</a></td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
  @include('partials.paginacao', ['p' => $veiculos])
  @endif
</section>
@endsection
