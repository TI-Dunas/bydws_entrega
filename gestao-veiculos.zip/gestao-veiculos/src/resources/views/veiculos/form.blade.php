@extends('layouts.app')
@section('titulo', $veiculo->exists ? 'Veículo '.$veiculo->chassi : 'Cadastrar veículo')
@section('estilo')
.cabecalho-veiculo{display:flex;gap:1.25rem;align-items:center;flex-wrap:wrap}
.grupo-titulo{display:flex;justify-content:space-between;align-items:baseline;gap:1rem;flex-wrap:wrap;margin-bottom:.9rem}
.grupo-titulo h2{margin:0}
.bloco.bloqueado{background:#FAFBFB}
.salvar{position:sticky;bottom:0;background:var(--papel);padding:.9rem 0;border-top:1px solid var(--linha);display:flex;gap:.75rem;align-items:center;flex-wrap:wrap}
@endsection
@section('conteudo')
@php
  $user = auth()->user();
  $campos = config('veiculos.campos') + config('veiculos.opcionais');
  $grupos = config('veiculos.grupos');
  $sug = config('veiculos.sugestoes');
@endphp
<div class="topo">
  <div class="cabecalho-veiculo">
    @if($veiculo->exists && $user->veCampo('placa')) @include('partials.placa', ['placa' => $veiculo->placa, 'classe' => 'grande']) @endif
    <div>
      <h1>{{ $veiculo->exists ? ($veiculo->modelo ?: 'Veículo sem modelo') : 'Cadastrar veículo' }}</h1>
      @if($veiculo->exists)<p class="mono">{{ $veiculo->chassi }} · {{ $veiculo->loja?->codigo }} {{ $veiculo->loja?->nome }}</p>@endif
    </div>
  </div>
  <a class="botao secundario" href="{{ route('veiculos.index') }}">Voltar para a lista</a>
</div>

<form method="post" action="{{ $veiculo->exists ? route('veiculos.update', $veiculo) : route('veiculos.store') }}">
  @csrf
  @if($veiculo->exists) @method('put') @endif

  @if($user->pode('veiculos.vinculos') || !$veiculo->exists)
  <section class="bloco">
    <div class="grupo-titulo"><h2>Loja e vendedor</h2></div>
    <div class="campos">
      <div><label for="loja_id">Loja</label>
        <select id="loja_id" name="loja_id" required>
          @foreach($lojas as $l)<option value="{{ $l->id }}" @selected(old('loja_id', $veiculo->loja_id) == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach
        </select></div>
      <div><label for="vendedor_id">Vendedor (consultor)</label>
        <select id="vendedor_id" name="vendedor_id">
          <option value="">Usar o texto do campo consultor</option>
          @foreach($vendedores as $vd)<option value="{{ $vd->id }}" @selected(old('vendedor_id', $veiculo->vendedor_id) == $vd->id)>{{ $vd->nome }}</option>@endforeach
        </select>
        <p class="dica">Ao escolher um vendedor, o nome dele substitui o campo consultor.</p></div>
    </div>
  </section>
  @endif

  @foreach($grupos as $g => $tituloGrupo)
    @php
      $editavelGrupo = in_array($g, $user->gruposEditaveis(), true);
      $visiveisGrupo = array_filter($campos, fn ($d, $c) => $d['grupo'] === $g && $user->veCampo($c), ARRAY_FILTER_USE_BOTH);
    @endphp
    @continue(empty($visiveisGrupo))
    <section class="bloco {{ $editavelGrupo ? '' : 'bloqueado' }}">
      <div class="grupo-titulo">
        <h2>{{ $tituloGrupo }}</h2>
        @if(!$editavelGrupo)<span class="selo">Somente leitura para o seu perfil</span>@elseif(count(array_intersect(array_keys($visiveisGrupo), $editaveis)) < count($visiveisGrupo))<span class="selo">Alguns campos somente leitura</span>@endif
      </div>
      <div class="campos">
      @foreach($visiveisGrupo as $c => $def)
        @php
          $pode = in_array($c, $editaveis, true);
          $valor = old($c, match($def['tipo']) {
            'date' => $veiculo->{$c}?->format('Y-m-d'),
            'time' => $veiculo->{$c} ? substr($veiculo->{$c}, 0, 5) : null,
            default => $veiculo->{$c},
          });
        @endphp
        <div class="{{ $def['tipo'] === 'text' ? 'largo' : '' }}">
          <label for="f_{{ $c }}">{{ $def['label'] }}</label>
          @if(!$pode)
            <div id="f_{{ $c }}" class="somente-leitura" style="padding:.5rem .6rem;border:1px solid var(--linha);border-radius:var(--raio);min-height:2.4rem">{{ $veiculo->exists ? ($veiculo->valorFormatado($c) ?: '—') : '—' }}</div>
          @elseif($def['tipo'] === 'bool')
            <input type="hidden" name="{{ $c }}" value="0">
            <label class="marcar" style="margin-top:.45rem"><input type="checkbox" id="f_{{ $c }}" name="{{ $c }}" value="1" @checked($valor)> Sim</label>
          @elseif($def['tipo'] === 'text')
            <textarea id="f_{{ $c }}" name="{{ $c }}" rows="3">{{ $valor }}</textarea>
          @elseif($def['tipo'] === 'int')
            <input type="number" id="f_{{ $c }}" name="{{ $c }}" value="{{ $valor }}" min="0" max="10">
          @else
            <input type="{{ ['date' => 'date', 'time' => 'time'][$def['tipo']] ?? 'text' }}" id="f_{{ $c }}" name="{{ $c }}" value="{{ $valor }}"
              @if(isset($sug[$c])) list="l_{{ $c }}" @endif @if($c === 'chassi') required maxlength="30" @endif @if($c === 'placa') maxlength="10" @endif>
            @if(isset($sug[$c]))<datalist id="l_{{ $c }}">@foreach($sug[$c] as $s)<option value="{{ $s }}">@endforeach</datalist>@endif
          @endif
        </div>
      @endforeach
      </div>
    </section>
  @endforeach

  <div class="salvar">
    <button class="botao" type="submit">{{ $veiculo->exists ? 'Salvar alterações' : 'Cadastrar veículo' }}</button>
    @if($veiculo->exists)<span class="dica">Última alteração em {{ $veiculo->updated_at?->format('d/m/Y H:i') }}</span>@endif
  </div>
</form>

@if($veiculo->exists && $user->pode('veiculos.excluir'))
<form method="post" action="{{ route('veiculos.destroy', $veiculo) }}" onsubmit="return confirm('Excluir este veículo? Essa ação não pode ser desfeita.')" style="margin-top:1rem">
  @csrf @method('delete')
  <button class="botao perigo pequeno" type="submit">Excluir veículo</button>
</form>
@endif
@endsection
