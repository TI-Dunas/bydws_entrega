@extends('layouts.app')
@section('titulo', 'Lojas e tokens de API')
@section('conteudo')
<div class="topo"><div><h1>Lojas e tokens de API</h1><p>Cada token pertence a uma loja e só enxerga os dados dela, salvo se liberado para todas.</p></div></div>

@if($novo)
<div class="aviso ok" role="status">
  Token gerado. Copie agora: ele não será exibido novamente.
  <div style="display:flex;gap:.5rem;margin-top:.5rem"><input id="novoToken" class="mono" value="{{ $novo }}" readonly>
    <button class="botao pequeno" type="button" onclick="navigator.clipboard.writeText(document.getElementById('novoToken').value);this.textContent='Copiado'">Copiar</button></div>
</div>
@endif

<div class="grade g2">
<form class="bloco" method="post" action="{{ route('tokens.gerar') }}">
  @csrf
  <h2>Gerar token</h2>
  <div class="campos" style="grid-template-columns:1fr 1fr">
    <div><label for="t_loja">Loja</label><select id="t_loja" name="loja_id" required>
      @foreach($lojas as $l)<option value="{{ $l->id }}">{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
    <div><label for="t_nome">Identificação</label><input id="t_nome" name="nome" placeholder="Ex.: ERP filial" required></div>
    <div><label for="t_perm">Permissão</label><select id="t_perm" name="permissao">
      <option value="leitura">Somente consulta</option><option value="escrita">Consulta e importação</option></select></div>
    <div><label for="t_exp">Expira em (dias)</label><input type="number" id="t_exp" name="expira_dias" min="1" placeholder="Não expira"></div>
    <label class="marcar largo"><input type="checkbox" name="todas_lojas" value="1"> Permitir consultar todas as lojas (filtrando por codigo_loja)</label>
  </div>
  <div class="acoes" style="margin-top:1rem"><button class="botao" type="submit">Gerar token</button></div>
</form>

<section class="bloco">
  <h2>Lojas</h2>
  <form class="filtros" method="post" action="{{ route('lojas.store') }}" style="margin-bottom:1rem">
    @csrf
    <div style="flex:0 1 120px"><label for="l_cod">Código</label><input id="l_cod" name="codigo" required></div>
    <div style="flex:1 1 180px"><label for="l_nome">Nome</label><input id="l_nome" name="nome" required></div>
    <div style="flex:0 0 auto"><button class="botao secundario" type="submit">Cadastrar loja</button></div>
  </form>
  <div class="tabela"><table>
    <thead><tr><th>Código</th><th>Nome</th><th class="num">Veículos</th></tr></thead>
    <tbody>@foreach($lojas as $l)<tr><td class="mono">{{ $l->codigo }}</td><td>{{ $l->nome }}</td><td class="num">{{ $l->veiculos_count }}</td></tr>@endforeach</tbody>
  </table></div>
</section>
</div>

<section class="bloco">
  <h2>Tokens ativos</h2>
  @if($tokens->isEmpty())
    <p class="vazio">Nenhum token gerado.</p>
  @else
  <div class="tabela"><table>
    <thead><tr><th>Identificação</th><th>Loja</th><th>Permissões</th><th>Último uso</th><th>Expira</th><th></th></tr></thead>
    <tbody>
    @foreach($tokens as $t)
      <tr>
        <td>{{ $t->name }}</td>
        <td>{{ $lojas->firstWhere('id', $t->tokenable_id)?->codigo }}</td>
        <td>
          <span class="selo azul">Consulta</span>
          @if(in_array('write', $t->abilities ?? []))<span class="selo azul">Importação</span>@endif
          @if(in_array('all-lojas', $t->abilities ?? []))<span class="selo alerta">Todas as lojas</span>@endif
        </td>
        <td>{{ $t->last_used_at?->format('d/m/Y H:i') ?? 'Nunca' }}</td>
        <td>{{ $t->expires_at?->format('d/m/Y') ?? 'Não expira' }}</td>
        <td><form method="post" action="{{ route('tokens.revogar', $t->id) }}" onsubmit="return confirm('Revogar este token? Integrações que o usam deixarão de funcionar.')">@csrf @method('delete')
          <button class="botao pequeno perigo" type="submit">Revogar</button></form></td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
  @endif
</section>

<section class="bloco">
  <h2>Como usar</h2>
  <p class="dica" style="margin:0 0 .5rem">Envie o token no cabeçalho de todas as requisições:</p>
<pre class="mono" style="background:var(--papel);padding:1rem;border-radius:var(--raio);overflow-x:auto;margin:0">curl -H "Authorization: Bearer SEU_TOKEN" -H "Accept: application/json" \
     "{{ url('/api/carros') }}?chassi=9BW&codigo_loja=001"

GET  /api/vendedores        ?codigo_loja &status=Ativo &nome
GET  /api/clientes          ?codigo_loja &cpf_cnpj &nome
GET  /api/carros            ?codigo_loja &chassi &modelo &placa &completo=1
GET  /api/veiculos/exportar ?codigo_loja
POST /api/veiculos/importar  arquivo=@planilha.xlsx  vendedor_id (opcional)</pre>
</section>
@endsection
