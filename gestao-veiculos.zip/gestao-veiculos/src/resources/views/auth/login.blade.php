<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrar · {{ config('app.name') }}</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Semi+Condensed:wght@600&family=Barlow+Condensed:wght@600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#123C45;font-family:"Barlow",system-ui,sans-serif;color:#1B262B;padding:1rem}
.cartao{background:#fff;border-radius:8px;width:100%;max-width:380px;padding:2rem}
.placa{display:flex;flex-direction:column;width:190px;margin:0 auto 1.5rem;border:2px solid #1B262B;border-radius:6px;overflow:hidden}
.placa::before{content:"BRASIL";background:#1D4EA3;color:#fff;font:600 10px/1 "Barlow",sans-serif;letter-spacing:.14em;text-align:center;padding:4px 0}
.placa span{font:600 2.1rem/1.3 "Barlow Condensed","Arial Narrow",sans-serif;letter-spacing:.08em;text-align:center}
h1{font-family:"Barlow Semi Condensed",sans-serif;font-weight:600;font-size:1.4rem;text-align:center;margin:0 0 1.5rem}
label{display:block;font-size:.85rem;font-weight:500;color:#5B6A6F;margin:0 0 .25rem}
input{font:inherit;width:100%;padding:.6rem;border:1px solid #D5DCDB;border-radius:6px;margin-bottom:1rem}
input[type=checkbox]{width:auto;margin:0}
.lembrar{display:flex;gap:.5rem;align-items:center;margin-bottom:1.25rem;font-size:.9rem}
button{width:100%;font:inherit;font-weight:600;background:#1D4EA3;color:#fff;border:0;border-radius:6px;padding:.7rem;cursor:pointer}
:focus-visible{outline:2px solid #1D4EA3;outline-offset:2px}
.erro{background:#FBE7E5;color:#B3362D;padding:.6rem .8rem;border-radius:6px;margin-bottom:1rem;font-size:.9rem}
</style>
</head>
<body>
<form class="cartao" method="post" action="{{ url('/login') }}">
  @csrf
  <div class="placa" aria-hidden="true"><span>ENT 2G26</span></div>
  <h1>Entregas e emplacamento</h1>
  @error('email')<div class="erro" role="alert">{{ $message }}</div>@enderror
  <label for="email">E-mail</label>
  <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus autocomplete="username">
  <label for="password">Senha</label>
  <input id="password" type="password" name="password" required autocomplete="current-password">
  <label class="lembrar"><input type="checkbox" name="lembrar" value="1"> Manter conectado</label>
  <button type="submit">Entrar</button>
</form>
</body>
</html>
