@extends('layouts.app')
@section('titulo', 'Consulta')
@section('conteudo')
@php($q = request()->except(['aba', 'page']))
<div class="topo"><div><h1>Consulta</h1><p>Pesquise vendedores ativos, clientes e carros pelo código da loja.</p></div></div>

<nav class="abas" aria-label="Entidades">
  @foreach(['vendedores' => 'Vendedores ativos', 'clientes' => 'Clientes', 'carros' => 'Carros'] as $k => $r)
    <a href="?{{ http_build_query(['aba' => $k, 'codigo_loja' => request('codigo_loja')]) }}" @if($aba === $k) aria-current="page" @endif>{{ $r }}</a>
  @endforeach
</nav>

<form class="bloco filtros" method="get">
  <input type="hidden" name="aba" value="{{ $aba }}">
  @if($lojas->isNotEmpty())
    <div><label for="codigo_loja">Código da loja</label>
      <input id="codigo_loja" name="codigo_loja" value="{{ request('codigo_loja') }}" list="lojas" placeholder="Todas">
      <datalist id="lojas">@foreach($lojas as $l)<option value="{{ $l->codigo }}">{{ $l->nome }}</option>@endforeach</datalist></div>
  @else
    <div><label>Código da loja</label><input value="{{ $loja?->codigo }}" readonly></div>
  @endif
  @if($aba === 'vendedores')
    <div><label for="nome">Nome</label><input id="nome" name="nome" value="{{ request('nome') }}"></div>
  @elseif($aba === 'clientes')
    <div><label for="cpf_cnpj">CPF/CNPJ</label><input id="cpf_cnpj" name="cpf_cnpj" value="{{ request('cpf_cnpj') }}" inputmode="numeric"></div>
    <div><label for="nome">Nome</label><input id="nome" name="nome" value="{{ request('nome') }}"></div>
  @else
    <div><label for="chassi">Chassi</label><input id="chassi" name="chassi" value="{{ request('chassi') }}"></div>
    <div><label for="modelo">Modelo</label><input id="modelo" name="modelo" value="{{ request('modelo') }}"></div>
    <div><label for="placa">Placa</label><input id="placa" name="placa" value="{{ request('placa') }}"></div>
  @endif
  <div style="flex:0 0 auto"><button class="botao" type="submit">Pesquisar</button></div>
</form>

<section class="bloco">
@if($lojaInvalida)
  <p class="vazio">Não existe loja com o código “{{ request('codigo_loja') }}”. Confira o código e pesquise de novo.</p>
@elseif($resultado->isEmpty())
  <p class="vazio">Nenhum resultado para os filtros informados.</p>
@else
  <div class="tabela"><table>
  @if($aba === 'vendedores')
    <thead><tr><th>ID vendedor</th><th>Consultor</th><th>CRM</th><th>Status do vendedor</th><th>Loja</th><th>Origem</th></tr></thead>
    <tbody>@foreach($resultado as $v)
      <tr><td class="mono">{{ $v->id }}</td><td>{{ $v->nome }}</td><td>{{ $v->crm ?: '—' }}</td>
        <td><span class="selo {{ $v->status === 'Ativo' ? 'ok' : '' }}">{{ $v->status }}</span></td>
        <td>{{ $v->loja?->codigo ?? '—' }}</td><td>{{ $v->origem === 'glpi' ? 'GLPI' : 'Manual' }}</td></tr>
    @endforeach</tbody>
  @elseif($aba === 'clientes')
    <thead><tr><th>Cliente</th><th>Contato</th><th>CPF/CNPJ</th><th>Histórico de compras</th></tr></thead>
    <tbody>@foreach($resultado as $c)
      <tr><td>{{ $c->nome }}</td><td>{{ $c->contato ?: '—' }}</td><td class="mono">{{ $c->cpf_cnpj ?: '—' }}</td>
        <td>@forelse($c->compras as $v)
              <div><a href="{{ route('veiculos.edit', $v->id) }}">{{ $v->modelo }}</a> <span class="mono" style="color:var(--suave)">{{ $v->chassi }}</span>
                {{ $v->faturamento?->format('d/m/Y') }} @if($v->entregue)<span class="selo ok">Entregue</span>@endif</div>
            @empty<span style="color:var(--suave)">Sem compras registradas</span>@endforelse</td></tr>
    @endforeach</tbody>
  @else
    <thead><tr><th>Placa</th><th>Modelo</th><th>Chassi</th><th>Modalidade</th><th>Status do veículo</th><th>Loja</th></tr></thead>
    <tbody>@foreach($resultado as $v)
      <tr><td>@include('partials.placa', ['placa' => $v->placa])</td>
        <td><a href="{{ route('veiculos.edit', $v) }}">{{ $v->modelo }}</a></td><td class="mono">{{ $v->chassi }}</td>
        <td>{{ $v->modalidade ?: '—' }}</td><td>{{ $v->status_veiculo ?: '—' }}</td><td>{{ $v->loja?->codigo }}</td></tr>
    @endforeach</tbody>
  @endif
  </table></div>
  @include('partials.paginacao', ['p' => $resultado])
@endif
</section>
@endsection
