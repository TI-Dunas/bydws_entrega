@extends('layouts.app')
@section('titulo', 'Sem acesso')
@section('conteudo')
<section class="bloco" style="max-width:560px">
  <h1 style="margin-bottom:.5rem">Seu perfil ainda não tem nenhuma área liberada</h1>
  <p>Peça a um administrador para liberar áreas no perfil {{ auth()->user()->perfilRel?->nome ?? auth()->user()->perfil }}, em Usuários › Perfis.</p>
</section>
@endsection
