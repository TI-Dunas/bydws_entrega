@extends('layouts.app')
@section('titulo', 'Dashboard de entregas')
@section('estilo')
.painel{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));background:var(--superficie);border:1px solid var(--linha);border-radius:var(--raio);margin-bottom:1.25rem}
.painel div{padding:1rem 1.25rem;border-left:1px solid var(--linha)}
.painel div:first-child{border-left:0}
.painel strong{display:block;font:700 2rem/1.1 var(--titulo);font-variant-numeric:tabular-nums}
.painel span{font-size:.88rem;color:var(--suave)}
.painel .ok strong{color:var(--ok)} .painel .erro strong{color:var(--erro)}
.barra{height:6px;background:var(--papel);border-radius:99px;overflow:hidden;margin-top:.5rem}
.barra i{display:block;height:100%;background:var(--ok)}
.grafico{position:relative;height:300px}
.proxima{display:flex;gap:.9rem;align-items:center;padding:.6rem 0;border-bottom:1px solid var(--linha)}
.proxima:last-child{border-bottom:0}
.proxima .quando{min-width:62px;text-align:center;font-family:var(--titulo);line-height:1.15}
.proxima .quando b{display:block;font-size:1.3rem}
.proxima .quando small{color:var(--suave)}
.proxima .info{flex:1;min-width:0}
.proxima .info div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.proxima .info small{color:var(--suave)}
.proxima.atrasada .quando b{color:var(--erro)}
@endsection
@section('conteudo')
<div class="topo">
  <div>
    <h1>Entregas de {{ $inicio->format('d/m/Y') }} a {{ $fim->format('d/m/Y') }}</h1>
    <p>Baseado na data de entrega prevista ou realizada de cada veículo.</p>
  </div>
  @if(auth()->user()->pode('planilhas.exportar'))<a class="botao secundario" href="{{ route('planilhas.exportar', ['inicio' => $inicio->toDateString(), 'fim' => $fim->toDateString(), 'loja_id' => $lojaId]) }}">Exportar período (.xlsx)</a>@endif
</div>

<form class="bloco filtros" method="get">
  <div><label for="inicio">De</label><input type="date" id="inicio" name="inicio" value="{{ $inicio->toDateString() }}"></div>
  <div><label for="fim">Até</label><input type="date" id="fim" name="fim" value="{{ $fim->toDateString() }}"></div>
  <div><label for="agrupar">Agrupar por</label>
    <select id="agrupar" name="agrupar">
      @foreach(['dia' => 'Dia', 'semana' => 'Semana', 'mes' => 'Mês'] as $k => $r)<option value="{{ $k }}" @selected($agrupar === $k)>{{ $r }}</option>@endforeach
    </select></div>
  @if($lojas->isNotEmpty())
  <div><label for="loja_id">Loja</label>
    <select id="loja_id" name="loja_id"><option value="">Todas</option>
      @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($lojaId == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach
    </select></div>
  @endif
  <div style="flex:0 0 auto"><button class="botao" type="submit">Aplicar</button></div>
  <div class="acoes" style="flex:1 1 auto">
    <a class="botao pequeno secundario" href="?inicio={{ now()->toDateString() }}&fim={{ now()->toDateString() }}">Hoje</a>
    <a class="botao pequeno secundario" href="?inicio={{ now()->startOfWeek()->toDateString() }}&fim={{ now()->endOfWeek()->toDateString() }}">Esta semana</a>
    <a class="botao pequeno secundario" href="?inicio={{ now()->startOfMonth()->toDateString() }}&fim={{ now()->endOfMonth()->toDateString() }}">Este mês</a>
    <a class="botao pequeno secundario" href="?inicio={{ now()->subMonths(2)->startOfMonth()->toDateString() }}&fim={{ now()->endOfMonth()->toDateString() }}&agrupar=semana">Últimos 3 meses</a>
  </div>
</form>

<section class="painel" aria-label="Indicadores do período">
  <div><strong>{{ $total }}</strong><span>entregas programadas</span></div>
  <div class="ok"><strong>{{ $entregues }}</strong><span>entregues</span>
    <div class="barra" aria-hidden="true"><i style="width:{{ $total ? round($entregues / $total * 100) : 0 }}%"></i></div></div>
  <div><strong>{{ $total - $entregues }}</strong><span>a entregar</span></div>
  <div class="{{ $atrasadas ? 'erro' : '' }}"><strong>{{ $atrasadas }}</strong><span>com data vencida e não entregues</span></div>
  <div><strong>{{ $nps === null ? '—' : $nps }}</strong><span>NPS do período ({{ $avaliacoes }} {{ $avaliacoes === 1 ? 'avaliação' : 'avaliações' }})</span></div>
</section>

<div class="grade" style="grid-template-columns:minmax(0,2fr) minmax(280px,1fr)">
  <section class="bloco">
    <h2>Entregas por {{ ['dia' => 'dia', 'semana' => 'semana', 'mes' => 'mês'][$agrupar] }}</h2>
    <div class="grafico"><canvas id="grafSerie" aria-label="Gráfico de entregas por período"></canvas></div>
  </section>
  <section class="bloco">
    <h2>Próximas entregas</h2>
    @forelse($proximas as $v)
      <a class="proxima {{ $v->data_entrega->lt(now()->startOfDay()) ? 'atrasada' : '' }}" href="{{ auth()->user()->pode('veiculos.ver') ? route('veiculos.edit', $v->id) : '#' }}" style="text-decoration:none;color:inherit">
        <div class="quando"><b>{{ $v->data_entrega->format('d/m') }}</b><small>{{ $v->hora_entrega ? substr($v->hora_entrega, 0, 5) : ($v->periodo_entrega ?: 'sem hora') }}</small></div>
        <div class="info"><div>{{ $v->modelo }}</div><small>{{ $v->cliente ?: 'Cliente não informado' }}</small></div>
        @include('partials.placa', ['placa' => $v->placa])
      </a>
    @empty
      <p class="vazio">Nenhuma entrega pendente no período.</p>
    @endforelse
  </section>
</div>

<div class="grade g2">
  <section class="bloco">
    <h2>Por período de entrega</h2>
    <div class="grafico" style="height:240px"><canvas id="grafPeriodo"></canvas></div>
  </section>
  <section class="bloco">
    <h2>Status das placas</h2>
    <div class="grafico" style="height:240px"><canvas id="grafPlaca"></canvas></div>
  </section>
</div>

<section class="bloco">
  <h2>Por consultor</h2>
  @if($porConsultor->isEmpty())
    <p class="vazio">Sem entregas no período.</p>
  @else
  <div class="tabela"><table>
    <thead><tr><th>Consultor</th><th class="num">Programadas</th><th class="num">Entregues</th><th class="num">% entregue</th><th class="num">Nota média</th></tr></thead>
    <tbody>
    @foreach($porConsultor as $c)
      <tr><td>{{ $c['nome'] }}</td><td class="num">{{ $c['total'] }}</td><td class="num">{{ $c['entregues'] }}</td>
        <td class="num">{{ round($c['entregues'] / $c['total'] * 100) }}%</td>
        <td class="num">{{ $c['nps'] === null ? '—' : number_format($c['nps'], 1, ',', '.') }}</td></tr>
    @endforeach
    </tbody>
  </table></div>
  @endif
</section>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function () {
  if (!window.Chart) return;
  Chart.defaults.font.family = '"Barlow", system-ui, sans-serif';
  Chart.defaults.color = '#5B6A6F';
  const serie = @json($serie);
  new Chart(document.getElementById('grafSerie'), {
    type: 'bar',
    data: { labels: serie.rotulos, datasets: [
      { label: 'Entregues', data: serie.entregues, backgroundColor: '#2F7A4C', borderRadius: 3 },
      { label: 'A entregar', data: serie.pendentes, backgroundColor: '#9DB4D8', borderRadius: 3 }
    ]},
    options: { maintainAspectRatio: false, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } },
               plugins: { legend: { position: 'bottom' } } }
  });
  const barras = (id, dados, cor) => new Chart(document.getElementById(id), {
    type: 'bar',
    data: { labels: Object.keys(dados), datasets: [{ data: Object.values(dados), backgroundColor: cor, borderRadius: 3 }] },
    options: { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false } },
               scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { grid: { display: false } } } }
  });
  barras('grafPeriodo', @json($porPeriodo), '#1D4EA3');
  barras('grafPlaca', @json($porStatusPlaca), '#1D5562');
})();
</script>
@endpush
