<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('titulo', 'Painel') · {{ config('app.name') }}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Semi+Condensed:wght@500;600;700&family=Barlow+Condensed:wght@600&display=swap" rel="stylesheet">
<style>
:root{
  --papel:#F2F4F3; --superficie:#FFFFFF; --linha:#D5DCDB; --tinta:#1B262B; --suave:#5B6A6F;
  --petroleo:#123C45; --petroleo-claro:#1D5562; --mercosul:#1D4EA3; --mercosul-fundo:#E7EEF9;
  --ok:#2F7A4C; --ok-fundo:#E4F2E9; --alerta:#9A5C00; --alerta-fundo:#FBF0DC; --erro:#B3362D; --erro-fundo:#FBE7E5;
  --raio:6px; --corpo:"Barlow",system-ui,-apple-system,"Segoe UI",sans-serif;
  --titulo:"Barlow Semi Condensed","Arial Narrow",system-ui,sans-serif;
}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{font-family:var(--corpo);font-size:15px;line-height:1.5;color:var(--tinta);background:var(--papel);display:grid;grid-template-columns:232px 1fr;min-height:100%}
a{color:var(--mercosul)}
:focus-visible{outline:2px solid var(--mercosul);outline-offset:2px}
h1,h2,h3{font-family:var(--titulo);font-weight:600;line-height:1.2;margin:0}
h1{font-size:1.75rem} h2{font-size:1.2rem;margin-bottom:.75rem} h3{font-size:1rem}

/* barra lateral */
.lateral{background:var(--petroleo);color:#DCE8EA;padding:1.25rem .75rem;display:flex;flex-direction:column;gap:1.25rem;position:sticky;top:0;height:100vh;overflow-y:auto}
.marca{font-family:var(--titulo);font-weight:700;font-size:1.15rem;color:#fff;padding:0 .6rem;line-height:1.15}
.marca small{display:block;font-family:var(--corpo);font-weight:400;font-size:.8rem;color:#9FBEC4}
.lateral nav{display:flex;flex-direction:column;gap:2px}
.lateral nav p{font-size:.78rem;color:#86A9B0;margin:.9rem .6rem .25rem}
.lateral nav a{color:#DCE8EA;text-decoration:none;padding:.45rem .6rem;border-radius:var(--raio)}
.lateral nav a:hover{background:var(--petroleo-claro)}
.lateral nav a[aria-current=page]{background:#fff;color:var(--petroleo);font-weight:600}
.usuario{margin-top:auto;font-size:.85rem;padding:0 .6rem;color:#9FBEC4}
.usuario strong{color:#fff;display:block}
.usuario button{background:none;border:0;color:#DCE8EA;padding:0;margin-top:.35rem;cursor:pointer;text-decoration:underline;font:inherit}

main{padding:1.75rem 2rem 3rem;min-width:0}
.topo{display:flex;align-items:flex-end;justify-content:space-between;gap:1rem;flex-wrap:wrap;margin-bottom:1.25rem}
.topo p{margin:.2rem 0 0;color:var(--suave)}

.bloco{background:var(--superficie);border:1px solid var(--linha);border-radius:var(--raio);padding:1.25rem;margin-bottom:1.25rem}
.grade{display:grid;gap:1.25rem}
.g2{grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}

/* formulários */
label{display:block;font-size:.85rem;font-weight:500;color:var(--suave);margin-bottom:.25rem}
input,select,textarea{font:inherit;width:100%;padding:.5rem .6rem;border:1px solid var(--linha);border-radius:var(--raio);background:#fff;color:var(--tinta)}
input[type=checkbox]{width:auto}
input[readonly],.somente-leitura{background:var(--papel);color:var(--suave)}
.campos{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:.9rem 1rem}
.campos .largo{grid-column:1/-1}
.filtros{display:flex;flex-wrap:wrap;gap:.75rem;align-items:flex-end}
.filtros>div{min-width:150px;flex:0 1 190px}
.marcar{display:flex;gap:.5rem;align-items:center;font-size:.9rem;color:var(--tinta);font-weight:400}
.dica{font-size:.85rem;color:var(--suave);margin:.35rem 0 0}

.botao{display:inline-flex;align-items:center;gap:.4rem;font:inherit;font-weight:600;border:1px solid var(--mercosul);background:var(--mercosul);color:#fff;padding:.5rem .95rem;border-radius:var(--raio);cursor:pointer;text-decoration:none;white-space:nowrap}
.botao:hover{filter:brightness(1.08)}
.botao.secundario{background:#fff;color:var(--mercosul)}
.botao.perigo{background:#fff;color:var(--erro);border-color:var(--erro)}
.botao.pequeno{padding:.25rem .6rem;font-size:.85rem}
.acoes{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}

/* tabelas */
.tabela{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.92rem}
th{text-align:left;font-weight:600;color:var(--suave);font-size:.82rem;padding:.5rem .6rem;border-bottom:2px solid var(--linha);white-space:nowrap}
td{padding:.55rem .6rem;border-bottom:1px solid var(--linha);vertical-align:middle}
tr:last-child td{border-bottom:0}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
.vazio{padding:2rem 1rem;text-align:center;color:var(--suave)}

.selo{display:inline-block;font-size:.8rem;font-weight:600;padding:.1rem .5rem;border-radius:99px;background:var(--papel);color:var(--suave);white-space:nowrap}
.selo.ok{background:var(--ok-fundo);color:var(--ok)}
.selo.alerta{background:var(--alerta-fundo);color:var(--alerta)}
.selo.erro{background:var(--erro-fundo);color:var(--erro)}
.selo.azul{background:var(--mercosul-fundo);color:var(--mercosul)}

.aviso{padding:.75rem 1rem;border-radius:var(--raio);margin-bottom:1rem;border-left:4px solid}
.aviso.ok{background:var(--ok-fundo);border-color:var(--ok)}
.aviso.erro{background:var(--erro-fundo);border-color:var(--erro)}
.aviso.info{background:var(--mercosul-fundo);border-color:var(--mercosul)}
.aviso ul{margin:.35rem 0 0;padding-left:1.1rem}

/* placa Mercosul */
.placa{display:inline-flex;flex-direction:column;width:96px;border:1.5px solid var(--tinta);border-radius:4px;background:#fff;overflow:hidden;vertical-align:middle;flex-shrink:0}
.placa::before{content:"BRASIL";background:var(--mercosul);color:#fff;font:600 7px/1 var(--corpo);letter-spacing:.12em;text-align:center;padding:2px 0}
.placa span{font:600 1.05rem/1.35 "Barlow Condensed","Arial Narrow",sans-serif;letter-spacing:.06em;text-align:center;color:var(--tinta)}
.placa.sem{border-style:dashed;border-color:var(--linha)}
.placa.sem::before{background:var(--linha);color:var(--suave)}
.placa.sem span{font:500 .78rem/1.85 var(--corpo);letter-spacing:0;color:var(--suave)}
.placa.grande{width:150px}.placa.grande::before{font-size:9px;padding:3px 0}.placa.grande span{font-size:1.7rem}

.abas{display:flex;gap:.25rem;border-bottom:2px solid var(--linha);margin-bottom:1.25rem;flex-wrap:wrap}
.abas a{padding:.55rem 1rem;text-decoration:none;color:var(--suave);font-weight:600;border-bottom:2px solid transparent;margin-bottom:-2px}
.abas a[aria-current=page]{color:var(--mercosul);border-color:var(--mercosul)}

.paginacao{display:flex;gap:.35rem;margin-top:1rem;flex-wrap:wrap;align-items:center}
.paginacao a,.paginacao span{padding:.25rem .6rem;border:1px solid var(--linha);border-radius:var(--raio);text-decoration:none;font-size:.88rem;background:#fff}
.paginacao span.atual{background:var(--mercosul);color:#fff;border-color:var(--mercosul)}
code,.mono{font-family:ui-monospace,"Cascadia Mono",Consolas,monospace;font-size:.88em}

@media (max-width:860px){
  body{grid-template-columns:1fr}
  .lateral{position:static;height:auto}
  main{padding:1.25rem 1rem 2rem}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
@yield('estilo')
</style>
</head>
<body>
@php($u = auth()->user())
<aside class="lateral">
  <div class="marca">Entregas e emplacamento<small>{{ $u->loja?->nome ?? 'Todas as lojas' }}</small></div>
  <nav aria-label="Principal">
    @if($u->pode('dashboard'))<a href="{{ route('dashboard') }}" @if(request()->routeIs('dashboard')) aria-current="page" @endif>Dashboard de entregas</a>@endif
    @if($u->pode('veiculos.ver'))<a href="{{ route('veiculos.index') }}" @if(request()->routeIs('veiculos.*')) aria-current="page" @endif>Veículos</a>@endif
    @if($u->pode('consulta'))<a href="{{ route('consulta') }}" @if(request()->routeIs('consulta')) aria-current="page" @endif>Consulta</a>@endif
    @if($u->pode('planilhas.importar') || $u->pode('glpi') || $u->pode('drive'))<p>Integrações</p>@endif
    @if($u->pode('planilhas.importar'))
      <a href="{{ route('planilhas.index') }}" @if(request()->routeIs('planilhas.*')) aria-current="page" @endif>Importar e exportar</a>
    @elseif($u->pode('planilhas.exportar'))
      <a href="{{ route('planilhas.index') }}" @if(request()->routeIs('planilhas.*')) aria-current="page" @endif>Exportar planilha</a>
    @endif
    @if($u->pode('glpi'))<a href="{{ route('glpi.index') }}" @if(request()->routeIs('glpi.*')) aria-current="page" @endif>GLPI e vendedores</a>@endif
    @if($u->pode('drive'))<a href="{{ route('drive.index') }}" @if(request()->routeIs('drive.*')) aria-current="page" @endif>Google Drive</a>@endif
    @if($u->pode('tokens') || $u->pode('usuarios'))<p>Administração</p>@endif
    @if($u->pode('tokens'))<a href="{{ route('tokens.index') }}" @if(request()->routeIs('tokens.*')) aria-current="page" @endif>Lojas e tokens de API</a>@endif
    @if($u->pode('usuarios'))
      <a href="{{ route('usuarios.index') }}" @if(request()->routeIs('usuarios.*')) aria-current="page" @endif>Usuários</a>
      <a href="{{ route('perfis.index') }}" @if(request()->routeIs('perfis.*')) aria-current="page" @endif>Perfis</a>
    @endif
  </nav>
  <div class="usuario">
    <strong>{{ $u->name }}</strong>
    Perfil {{ $u->perfilRel?->nome ?? $u->perfil }}
    <form method="post" action="{{ route('logout') }}">@csrf<button type="submit">Sair</button></form>
  </div>
</aside>
<main>
  @if(session('ok'))<div class="aviso ok" role="status">{{ session('ok') }}</div>@endif
  @if(session('erro'))<div class="aviso erro" role="alert">{{ session('erro') }}</div>@endif
  @if($errors->any())
    <div class="aviso erro" role="alert">Corrija os campos abaixo:<ul>@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>
  @endif
  @yield('conteudo')
</main>
@stack('scripts')
</body>
</html>
