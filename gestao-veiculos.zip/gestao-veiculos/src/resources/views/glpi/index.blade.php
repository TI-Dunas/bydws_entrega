@extends('layouts.app')
@section('titulo', 'GLPI e vendedores')
@section('conteudo')
<div class="topo"><div><h1>GLPI e vendedores</h1><p>Os consultores são os usuários do GLPI cujo DN do LDAP contém OU={{ $cfg['ou'] }}.</p></div>
  <div class="acoes">
    <form method="post" action="{{ route('glpi.testar') }}">@csrf<button class="botao secundario" type="submit">Testar conexão</button></form>
    <form method="post" action="{{ route('glpi.sincronizar') }}">@csrf<button class="botao" type="submit">Sincronizar vendedores</button></form>
  </div>
</div>

<div class="grade g2">
<form class="bloco" method="post" action="{{ route('glpi.salvar') }}">
  @csrf
  <h2>Conexão com a API</h2>
  <div class="campos" style="grid-template-columns:1fr">
    <div><label for="url">URL do GLPI</label><input type="url" id="url" name="url" value="{{ old('url', $cfg['url']) }}" placeholder="https://glpi.empresa.com.br/apirest.php" required>
      <p class="dica">Pode informar com ou sem /apirest.php.</p></div>
    <div><label for="app_token">App-Token (Configurar › Geral › API)</label><input type="password" id="app_token" name="app_token" autocomplete="off" placeholder="{{ $cfg['tem_app_token'] ? 'Salvo. Preencha só para trocar' : 'Opcional, se o cliente da API exigir' }}"></div>
    <div><label for="user_token">Token de usuário (Preferências › Chaves de acesso remoto)</label><input type="password" id="user_token" name="user_token" autocomplete="off" placeholder="{{ $cfg['tem_user_token'] ? 'Salvo. Preencha só para trocar' : 'Obrigatório' }}"></div>
    <div><label for="ou">Unidade organizacional (OU) dos vendedores</label><input id="ou" name="ou" value="{{ old('ou', $cfg['ou']) }}" required></div>
    <div><label for="loja_padrao_id">Loja atribuída a vendedores novos</label>
      <select id="loja_padrao_id" name="loja_padrao_id"><option value="">Nenhuma (definir manualmente)</option>
        @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($cfg['loja_padrao_id'] == $l->id)>{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
    <label class="marcar"><input type="checkbox" name="verificar_ssl" value="1" @checked($cfg['verificar_ssl'] === '1')> Verificar certificado SSL</label>
    <label class="marcar"><input type="checkbox" name="auto" value="1" @checked($cfg['auto'] === '1')> Sincronizar automaticamente a cada hora</label>
  </div>
  <div class="acoes" style="margin-top:1rem"><button class="botao" type="submit">Salvar conexão</button></div>
</form>

<form class="bloco" method="post" action="{{ route('vendedores.store') }}">
  @csrf
  <h2>Cadastrar vendedor manualmente</h2>
  <p class="dica" style="margin:0 0 .9rem">Para consultores que ainda não estão no GLPI. A próxima sincronização não altera vendedores manuais.</p>
  <div class="campos" style="grid-template-columns:1fr">
    <div><label for="v_nome">Nome</label><input id="v_nome" name="nome" required></div>
    <div><label for="v_loja">Loja</label><select id="v_loja" name="loja_id"><option value="">Sem loja</option>
      @foreach($lojas as $l)<option value="{{ $l->id }}">{{ $l->codigo }} · {{ $l->nome }}</option>@endforeach</select></div>
    <div><label for="v_crm">CRM</label><input id="v_crm" name="crm"></div>
  </div>
  <div class="acoes" style="margin-top:1rem"><button class="botao secundario" type="submit">Cadastrar vendedor</button></div>
</form>
</div>

<section class="bloco">
  <h2>Vendedores</h2>
  @if($vendedores->isEmpty())
    <p class="vazio">Nenhum vendedor ainda. Salve a conexão e clique em Sincronizar vendedores.</p>
  @else
  <div class="tabela"><table>
    <thead><tr><th>ID</th><th>Consultor</th><th>Login</th><th>Origem</th><th>Loja</th><th>CRM</th><th>Status</th><th></th></tr></thead>
    <tbody>
    @foreach($vendedores as $v)
      <tr>
        <td class="mono">{{ $v->id }}</td>
        <td>{{ $v->nome }}@if($v->user_dn)<div class="dica mono" style="margin:0" title="{{ $v->user_dn }}">{{ \Illuminate\Support\Str::limit($v->user_dn, 48) }}</div>@endif</td>
        <td>{{ $v->login ?: '—' }}</td>
        <td>{{ $v->origem === 'glpi' ? 'GLPI #'.$v->glpi_id : 'Manual' }}</td>
        <td colspan="4">
          <form method="post" action="{{ route('vendedores.update', $v) }}" class="acoes" style="flex-wrap:nowrap">
            @csrf @method('put')
            <select name="loja_id" aria-label="Loja de {{ $v->nome }}" style="min-width:150px"><option value="">Sem loja</option>
              @foreach($lojas as $l)<option value="{{ $l->id }}" @selected($v->loja_id == $l->id)>{{ $l->codigo }}</option>@endforeach</select>
            <input name="crm" value="{{ $v->crm }}" aria-label="CRM de {{ $v->nome }}" placeholder="CRM" style="min-width:110px">
            <select name="status" aria-label="Status de {{ $v->nome }}" style="min-width:100px">
              <option @selected($v->status === 'Ativo')>Ativo</option><option @selected($v->status === 'Inativo')>Inativo</option></select>
            <button class="botao pequeno secundario" type="submit">Salvar</button>
          </form>
        </td>
      </tr>
    @endforeach
    </tbody>
  </table></div>
  @include('partials.paginacao', ['p' => $vendedores])
  @endif
</section>

@include('partials.logs')
@endsection
