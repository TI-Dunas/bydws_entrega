<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Cliente extends Model
{
    protected $table = 'clientes';
    protected $fillable = ['loja_id', 'nome', 'cpf_cnpj', 'contato'];

    public function loja(): BelongsTo
    {
        return $this->belongsTo(Loja::class);
    }

    /** Histórico de compras = veículos vinculados ao cliente */
    public function compras(): HasMany
    {
        return $this->hasMany(Veiculo::class)->orderByDesc('faturamento');
    }

    public static function somenteDigitos(?string $v): ?string
    {
        $d = preg_replace('/\D/', '', (string) $v);
        return $d === '' ? null : $d;
    }
}
