<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Vendedor extends Model
{
    protected $table = 'vendedores';
    protected $fillable = ['loja_id', 'glpi_id', 'nome', 'login', 'email', 'crm', 'status', 'origem', 'user_dn', 'sincronizado_em'];
    protected $casts = ['sincronizado_em' => 'datetime'];

    public function loja(): BelongsTo
    {
        return $this->belongsTo(Loja::class);
    }

    public function veiculos(): HasMany
    {
        return $this->hasMany(Veiculo::class);
    }

    public function scopeAtivos($q)
    {
        return $q->where('status', 'Ativo');
    }
}
