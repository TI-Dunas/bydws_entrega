<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Laravel\Sanctum\HasApiTokens;

/** A loja/filial é a dona dos tokens de API: o token define o escopo de dados. */
class Loja extends Model
{
    use HasApiTokens;

    protected $table = 'lojas';
    protected $fillable = ['codigo', 'nome', 'ativa'];
    protected $casts = ['ativa' => 'boolean'];

    public function veiculos(): HasMany
    {
        return $this->hasMany(Veiculo::class);
    }

    public function vendedores(): HasMany
    {
        return $this->hasMany(Vendedor::class);
    }
}
