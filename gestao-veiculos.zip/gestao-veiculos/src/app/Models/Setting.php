<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class Setting extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'chave';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['chave', 'valor'];

    /** Chaves guardadas criptografadas */
    private const SECRETAS = ['glpi.app_token', 'glpi.user_token'];

    public static function get(string $chave, $padrao = null)
    {
        $v = static::find($chave)?->valor;
        if ($v === null || $v === '') {
            return $padrao;
        }
        if (in_array($chave, self::SECRETAS, true)) {
            try {
                return Crypt::decryptString($v);
            } catch (\Throwable) {
                return $padrao;
            }
        }
        return $v;
    }

    public static function put(string $chave, $valor): void
    {
        if (in_array($chave, self::SECRETAS, true) && $valor !== null && $valor !== '') {
            $valor = Crypt::encryptString($valor);
        }
        static::updateOrCreate(['chave' => $chave], ['valor' => $valor]);
    }
}
