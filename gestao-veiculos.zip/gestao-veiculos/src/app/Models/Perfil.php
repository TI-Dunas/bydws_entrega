<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Perfil extends Model
{
    protected $table = 'perfis';
    protected $fillable = ['slug', 'nome', 'descricao', 'modulos', 'campos', 'sistema'];
    protected $casts = ['modulos' => 'array', 'campos' => 'array', 'sistema' => 'boolean'];

    public const NIVEIS = ['oculto' => 'Oculto', 'ler' => 'Leitura', 'editar' => 'Edição'];

    public function usuarios(): HasMany
    {
        return $this->hasMany(User::class, 'perfil', 'slug');
    }

    public function ehAdmin(): bool
    {
        return $this->slug === 'admin';
    }

    public function pode(string $modulo): bool
    {
        return $this->ehAdmin() || in_array($modulo, $this->modulos ?? [], true);
    }

    /** oculto | ler | editar */
    public function nivel(string $campo): string
    {
        return $this->ehAdmin() ? 'editar' : ($this->campos[$campo] ?? 'ler');
    }

    public static function todosModulos(): array
    {
        return array_merge(...array_values(array_map('array_keys', config('veiculos.modulos'))));
    }

    public static function todosCampos(): array
    {
        return config('veiculos.campos') + config('veiculos.opcionais');
    }
}
