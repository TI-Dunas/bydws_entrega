<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = ['name', 'email', 'password', 'perfil', 'loja_id'];
    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return ['email_verified_at' => 'datetime', 'password' => 'hashed'];
    }

    public function loja(): BelongsTo
    {
        return $this->belongsTo(Loja::class);
    }

    public function perfilRel(): BelongsTo
    {
        return $this->belongsTo(Perfil::class, 'perfil', 'slug');
    }

    public function isAdmin(): bool
    {
        return $this->perfil === 'admin';
    }

    /** Área do sistema liberada para o perfil do usuário */
    public function pode(string $modulo): bool
    {
        return $this->isAdmin() || (bool) $this->perfilRel?->pode($modulo);
    }

    /** Nível de acesso a um campo do veículo: oculto | ler | editar */
    public function nivelCampo(string $campo): string
    {
        if ($this->isAdmin()) {
            return 'editar';
        }
        return $this->perfilRel?->nivel($campo) ?? 'oculto';
    }

    public function veCampo(string $campo): bool
    {
        return $this->nivelCampo($campo) !== 'oculto';
    }

    /** Campos de veículo que o usuário pode editar */
    public function camposEditaveis(): array
    {
        return array_values(array_filter(array_keys(Perfil::todosCampos()), fn ($c) => $this->nivelCampo($c) === 'editar'));
    }

    /** Campos de veículo visíveis (leitura ou edição) */
    public function camposVisiveis(): array
    {
        return array_values(array_filter(array_keys(Perfil::todosCampos()), fn ($c) => $this->veCampo($c)));
    }

    /** Grupos com ao menos um campo editável */
    public function gruposEditaveis(): array
    {
        $defs = Perfil::todosCampos();
        return array_values(array_unique(array_map(fn ($c) => $defs[$c]['grupo'], $this->camposEditaveis())));
    }
}
