<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Veiculo extends Model
{
    protected $table = 'veiculos';
    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected function casts(): array
    {
        $casts = ['entregue' => 'boolean', 'nps' => 'integer'];
        foreach (config('veiculos.campos') as $campo => $def) {
            if ($def['tipo'] === 'date') {
                $casts[$campo] = 'date';
            }
        }
        return $casts;
    }

    public function loja(): BelongsTo
    {
        return $this->belongsTo(Loja::class);
    }

    public function vendedor(): BelongsTo
    {
        return $this->belongsTo(Vendedor::class);
    }

    public function clienteRel(): BelongsTo
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }

    public function scopeDaLoja($q, ?int $lojaId)
    {
        return $lojaId ? $q->where('loja_id', $lojaId) : $q;
    }

    /** Valor formatado para exibição/exportação */
    public function valorFormatado(string $campo): string
    {
        $v = $this->{$campo};
        $tipo = (config('veiculos.campos.'.$campo) ?? config('veiculos.opcionais.'.$campo))['tipo'] ?? 'string';

        return match (true) {
            $v === null || $v === '' => '',
            $tipo === 'date' => $v->format('d/m/Y'),
            $tipo === 'time' => substr((string) $v, 0, 5),
            $tipo === 'bool' => $v ? 'Sim' : 'Não',
            default => (string) $v,
        };
    }
}
