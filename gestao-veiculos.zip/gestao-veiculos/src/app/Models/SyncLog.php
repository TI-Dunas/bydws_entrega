<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SyncLog extends Model
{
    protected $table = 'sync_logs';
    protected $fillable = ['origem', 'acao', 'status', 'mensagem', 'user_id'];

    public static function registrar(string $origem, string $acao, bool $ok, string $mensagem): void
    {
        static::create([
            'origem'   => $origem,
            'acao'     => $acao,
            'status'   => $ok ? 'ok' : 'erro',
            'mensagem' => mb_substr($mensagem, 0, 5000),
            'user_id'  => auth()->id(),
        ]);
    }
}
