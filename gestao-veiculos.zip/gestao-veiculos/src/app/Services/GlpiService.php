<?php

namespace App\Services;

use App\Models\Setting;
use App\Models\Vendedor;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Integração com a API REST do GLPI (apirest.php).
 * Autenticação: App-Token + user_token -> initSession -> Session-Token.
 * Vendedores = usuários cujo DN do LDAP contém OU=<ou configurada> (padrão CE).
 */
class GlpiService
{
    private ?string $sessionToken = null;

    public function configurado(): bool
    {
        return (bool) (Setting::get('glpi.url') && Setting::get('glpi.user_token'));
    }

    private function baseUrl(): string
    {
        $url = rtrim((string) Setting::get('glpi.url'), '/');
        if (! str_ends_with($url, 'apirest.php')) {
            $url .= '/apirest.php';
        }
        return $url;
    }

    private function http(): PendingRequest
    {
        $headers = ['Content-Type' => 'application/json'];
        if ($app = Setting::get('glpi.app_token')) {
            $headers['App-Token'] = $app;
        }
        if ($this->sessionToken) {
            $headers['Session-Token'] = $this->sessionToken;
        }
        return Http::withHeaders($headers)
            ->timeout(60)
            ->withOptions(['verify' => Setting::get('glpi.verificar_ssl', '1') === '1']);
    }

    public function iniciarSessao(): void
    {
        if (! $this->configurado()) {
            throw new RuntimeException('Informe a URL do GLPI e o token de usuário.');
        }
        $r = $this->http()
            ->withHeaders(['Authorization' => 'user_token '.Setting::get('glpi.user_token')])
            ->get($this->baseUrl().'/initSession');

        if (! $r->successful() || ! $r->json('session_token')) {
            throw new RuntimeException('GLPI recusou a sessão (HTTP '.$r->status().'): '.$this->erro($r->body()));
        }
        $this->sessionToken = $r->json('session_token');
    }

    public function encerrarSessao(): void
    {
        if ($this->sessionToken) {
            try {
                $this->http()->get($this->baseUrl().'/killSession');
            } catch (\Throwable) {
            }
            $this->sessionToken = null;
        }
    }

    public function testar(): string
    {
        $this->iniciarSessao();
        try {
            $r = $this->http()->get($this->baseUrl().'/getFullSession');
            $nome = $r->json('session.glpiname') ?? 'desconhecido';
            return "Conexão estabelecida como \"{$nome}\".";
        } finally {
            $this->encerrarSessao();
        }
    }

    /** Busca usuários do GLPI filtrando pela OU no DN do LDAP */
    public function buscarUsuariosDaOu(?string $ou = null): array
    {
        $ou = trim($ou ?? Setting::get('glpi.ou', 'CE'));
        $padrao = '/(^|,)\s*OU\s*=\s*'.preg_quote($ou, '/').'\s*(,|$)/i';
        $porPagina = 200;
        $inicio = 0;
        $encontrados = [];

        $this->iniciarSessao();
        try {
            do {
                $r = $this->http()->get($this->baseUrl().'/User', [
                    'range'      => $inicio.'-'.($inicio + $porPagina - 1),
                    'is_deleted' => 0,
                ]);
                if (! in_array($r->status(), [200, 206], true)) {
                    throw new RuntimeException('Erro ao listar usuários (HTTP '.$r->status().'): '.$this->erro($r->body()));
                }
                foreach ($r->json() ?? [] as $u) {
                    if (! empty($u['user_dn']) && preg_match($padrao, $u['user_dn'])) {
                        $encontrados[] = $u;
                    }
                }
                $total = 0;
                if (preg_match('~/(\d+)$~', (string) $r->header('Content-Range'), $m)) {
                    $total = (int) $m[1];
                }
                $inicio += $porPagina;
            } while ($inicio < $total);
        } finally {
            $this->encerrarSessao();
        }

        return $encontrados;
    }

    /** Sincroniza a tabela de vendedores. Retorna resumo. */
    public function sincronizarVendedores(): array
    {
        $usuarios = $this->buscarUsuariosDaOu();
        $lojaPadrao = Setting::get('glpi.loja_padrao_id') ?: null;
        $idsGlpi = [];
        $novos = $atualizados = 0;

        foreach ($usuarios as $u) {
            $idsGlpi[] = (int) $u['id'];
            $nome = trim(($u['firstname'] ?? '').' '.($u['realname'] ?? '')) ?: ($u['name'] ?? 'Sem nome');

            $v = Vendedor::firstOrNew(['glpi_id' => (int) $u['id']]);
            $novo = ! $v->exists;
            $v->fill([
                'nome'            => $nome,
                'login'           => $u['name'] ?? null,
                'status'          => ! empty($u['is_active']) ? 'Ativo' : 'Inativo',
                'origem'          => 'glpi',
                'user_dn'         => $u['user_dn'] ?? null,
                'sincronizado_em' => now(),
            ]);
            if ($novo && $lojaPadrao) {
                $v->loja_id = $lojaPadrao;
            }
            $v->save();
            $novo ? $novos++ : $atualizados++;
        }

        // Quem saiu da OU (ou do GLPI) fica inativo
        $inativados = Vendedor::where('origem', 'glpi')
            ->whereNotIn('glpi_id', $idsGlpi ?: [0])
            ->where('status', 'Ativo')
            ->update(['status' => 'Inativo']);

        return compact('novos', 'atualizados', 'inativados') + ['total' => count($usuarios)];
    }

    private function erro(string $body): string
    {
        $j = json_decode($body, true);
        return is_array($j) ? implode(' - ', array_map('strval', $j)) : mb_substr($body, 0, 300);
    }
}
