<?php

namespace App\Services;

use App\Models\Cliente;
use App\Models\Vendedor;
use App\Models\Veiculo;

/** Regras de consulta compartilhadas entre a aba web e a API (seção 2 da especificação) */
class ConsultaService
{
    public function vendedores(?int $lojaId, array $f = [])
    {
        return Vendedor::with('loja')
            ->when($lojaId, fn ($q) => $q->where('loja_id', $lojaId))
            ->where('status', $f['status'] ?? 'Ativo')
            ->when($f['nome'] ?? null, fn ($q, $n) => $q->where('nome', 'like', "%{$n}%"))
            ->orderBy('nome');
    }

    public function clientes(?int $lojaId, array $f = [])
    {
        $doc = Cliente::somenteDigitos($f['cpf_cnpj'] ?? null);

        return Cliente::with(['loja', 'compras:id,cliente_id,modelo,chassi,placa,faturamento,data_entrega,entregue'])
            ->when($lojaId, fn ($q) => $q->where('loja_id', $lojaId))
            ->when($doc, fn ($q) => $q->where('cpf_cnpj', 'like', "%{$doc}%"))
            ->when($f['nome'] ?? null, fn ($q, $n) => $q->where('nome', 'like', "%{$n}%"))
            ->orderBy('nome');
    }

    public function carros(?int $lojaId, array $f = [])
    {
        return Veiculo::with(['loja', 'vendedor'])
            ->when($lojaId, fn ($q) => $q->where('loja_id', $lojaId))
            ->when($f['chassi'] ?? null, fn ($q, $c) => $q->where('chassi', 'like', '%'.strtoupper($c).'%'))
            ->when($f['modelo'] ?? null, fn ($q, $m) => $q->where('modelo', 'like', "%{$m}%"))
            ->when($f['placa'] ?? null, fn ($q, $p) => $q->where('placa', 'like', '%'.strtoupper($p).'%'))
            ->orderByDesc('id');
    }
}
