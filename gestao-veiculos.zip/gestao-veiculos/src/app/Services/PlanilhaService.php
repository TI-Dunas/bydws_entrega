<?php

namespace App\Services;

use App\Models\Cliente;
use App\Models\Loja;
use App\Models\Vendedor;
use App\Models\Veiculo;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class PlanilhaService
{
    /** Marcador de valor inválido na conversão */
    public const INVALIDO = "\0invalido";

    /** Campos homologados (obrigatórios) + opcionais, indexados pelo header normalizado */
    public function mapaCabecalhos(): array
    {
        $mapa = [];
        foreach (config('veiculos.campos') as $campo => $def) {
            $mapa[$this->normalizar($def['header'])] = ['campo' => $campo, 'obrigatorio' => true] + $def;
        }
        foreach (config('veiculos.opcionais') as $campo => $def) {
            $mapa[$this->normalizar($def['header'])] = ['campo' => $campo, 'obrigatorio' => false] + $def;
        }
        return $mapa;
    }

    public function cabecalhosHomologados(): array
    {
        return array_values(array_map(fn ($d) => $d['header'], config('veiculos.campos')));
    }

    /** Normalização mínima: caixa alta, espaços colapsados. Acentos e pontuação continuam obrigatórios. */
    public function normalizar(?string $h): string
    {
        return preg_replace('/\s+/u', ' ', mb_strtoupper(trim((string) $h), 'UTF-8'));
    }

    /** Valida estritamente os cabeçalhos. Retorna lista de erros (vazia = válido). */
    public function validarCabecalhos(array $headers): array
    {
        $mapa = $this->mapaCabecalhos();
        $recebidos = array_values(array_filter(array_map(fn ($h) => $this->normalizar($h), $headers), fn ($h) => $h !== ''));
        $erros = [];

        foreach ($mapa as $norm => $def) {
            if ($def['obrigatorio'] && ! in_array($norm, $recebidos, true)) {
                $erros[] = "Coluna obrigatória ausente: \"{$def['header']}\".";
            }
        }
        foreach ($recebidos as $h) {
            if (! isset($mapa[$h])) {
                $erros[] = "Coluna fora do layout homologado: \"{$h}\".";
            }
        }
        foreach (array_count_values($recebidos) as $h => $n) {
            if ($n > 1) {
                $erros[] = "Coluna repetida: \"{$h}\".";
            }
        }
        return $erros;
    }

    /** Lê um .xlsx e devolve todas as linhas (primeira linha = cabeçalho) */
    public function lerArquivo(string $caminho): array
    {
        $reader = IOFactory::createReaderForFile($caminho);
        $reader->setReadDataOnly(true);
        $sheet = $reader->load($caminho)->getActiveSheet();

        return $sheet->toArray(null, true, false, false);
    }

    /**
     * Importa linhas (primeira = cabeçalho) para a loja informada.
     * $vendedor: quando informado, é atribuído em lote a todos os registros.
     */
    public function importar(array $linhas, Loja $loja, ?Vendedor $vendedor = null): array
    {
        $linhas = array_values(array_filter($linhas, fn ($l) => is_array($l) && count(array_filter($l, fn ($c) => $c !== null && $c !== '')) > 0));
        if (count($linhas) === 0) {
            return ['ok' => false, 'erros' => ['A planilha está vazia.'], 'criados' => 0, 'atualizados' => 0, 'avisos' => []];
        }

        $headers = array_shift($linhas);
        $erros = $this->validarCabecalhos($headers);
        if ($erros) {
            return ['ok' => false, 'erros' => $erros, 'criados' => 0, 'atualizados' => 0, 'avisos' => []];
        }

        $mapa = $this->mapaCabecalhos();
        $indices = [];
        foreach ($headers as $i => $h) {
            $norm = $this->normalizar($h);
            if (isset($mapa[$norm])) {
                $indices[$i] = $mapa[$norm];
            }
        }

        $vendedoresLoja = Vendedor::where(fn ($q) => $q->where('loja_id', $loja->id)->orWhereNull('loja_id'))
            ->get()->keyBy(fn ($v) => mb_strtoupper(trim($v->nome)));

        $criados = $atualizados = 0;
        $avisos = [];

        DB::transaction(function () use ($linhas, $indices, $loja, $vendedor, $vendedoresLoja, &$criados, &$atualizados, &$avisos) {
            foreach ($linhas as $n => $linha) {
                $numLinha = $n + 2;
                $dados = [];
                foreach ($indices as $i => $def) {
                    $bruto = $linha[$i] ?? null;
                    $valor = $this->converter($bruto, $def['tipo']);
                    if ($valor === self::INVALIDO) {
                        $avisos[] = "Linha {$numLinha}: valor \"{$bruto}\" inválido em {$def['header']}; campo ignorado.";
                        continue;
                    }
                    $dados[$def['campo']] = $valor;
                }

                $chassi = strtoupper(trim((string) ($dados['chassi'] ?? '')));
                if ($chassi === '') {
                    $avisos[] = "Linha {$numLinha}: sem CHASSI; linha ignorada.";
                    continue;
                }
                $dados['chassi'] = $chassi;
                $dados['loja_id'] = $loja->id;
                $dados['entregue'] = (bool) ($dados['entregue'] ?? false);

                // Vendedor: lote > correspondência pelo nome do consultor
                if ($vendedor) {
                    $dados['vendedor_id'] = $vendedor->id;
                    $dados['consultor'] = $vendedor->nome;
                } elseif (! empty($dados['consultor'])) {
                    $v = $vendedoresLoja->get(mb_strtoupper(trim($dados['consultor'])));
                    $dados['vendedor_id'] = $v?->id;
                }

                // Cliente
                if (! empty($dados['cliente'])) {
                    $cliente = Cliente::firstOrCreate(['loja_id' => $loja->id, 'nome' => trim($dados['cliente'])]);
                    $dados['cliente_id'] = $cliente->id;
                }

                $veiculo = Veiculo::where('chassi', $chassi)->first();
                if ($veiculo) {
                    $veiculo->update($dados);
                    $atualizados++;
                } else {
                    Veiculo::create($dados);
                    $criados++;
                }
            }
        });

        return ['ok' => true, 'erros' => [], 'criados' => $criados, 'atualizados' => $atualizados, 'avisos' => $avisos];
    }

    /** Converte valor bruto. Retorna self::INVALIDO se não for possível. */
    public function converter($v, string $tipo)
    {
        if ($v === null || (is_string($v) && trim($v) === '')) {
            return $tipo === 'bool' ? false : null; // vazio
        }
        $s = is_string($v) ? trim($v) : $v;

        switch ($tipo) {
            case 'date':
                if (is_numeric($s)) {
                    return Carbon::instance(ExcelDate::excelToDateTimeObject((float) $s))->format('Y-m-d');
                }
                foreach (['d/m/Y', 'd/m/y', 'Y-m-d', 'd-m-Y', 'd.m.Y'] as $f) {
                    $d = \DateTime::createFromFormat('!'.$f, $s);
                    if ($d && $d->format($f) === $s) {
                        return $d->format('Y-m-d');
                    }
                }
                return self::INVALIDO;

            case 'time':
                if (is_numeric($s)) {
                    $seg = (int) round(fmod((float) $s, 1) * 86400);
                    return sprintf('%02d:%02d:00', intdiv($seg, 3600) % 24, intdiv($seg % 3600, 60));
                }
                if (preg_match('/^(\d{1,2})[:hH](\d{2})?/', $s, $m)) {
                    return sprintf('%02d:%02d:00', min(23, (int) $m[1]), (int) ($m[2] ?? 0));
                }
                return self::INVALIDO;

            case 'bool':
                $t = mb_strtoupper((string) $s);
                if (in_array($t, ['SIM', 'S', 'X', '1', 'TRUE', 'VERDADEIRO', 'OK', 'ENTREGUE'], true)) {
                    return true;
                }
                if (in_array($t, ['', 'NÃO', 'NAO', 'N', '0', 'FALSE', 'FALSO', '-'], true)) {
                    return self::INVALIDO;
                }
                return self::INVALIDO;

            case 'int':
                if (! is_numeric($s)) {
                    return self::INVALIDO;
                }
                $i = (int) round((float) $s);
                return ($i < 0 || $i > 10) ? self::INVALIDO : $i;

            default:
                return is_float($s) && floor($s) == $s ? (string) (int) $s : (string) $s;
        }
    }

    /** Linhas (cabeçalho + dados) para exportação */
    public function linhasExportacao(Builder $query, bool $incluirOpcionais = true, ?array $somente = null): array
    {
        $campos = config('veiculos.campos') + ($incluirOpcionais ? config('veiculos.opcionais') : []);
        if ($somente !== null) {
            $campos = array_intersect_key($campos, array_flip($somente)); // respeita campos ocultos do perfil
        }
        $linhas = [array_values(array_map(fn ($d) => $d['header'], $campos))];

        $query->orderBy('id')->chunk(500, function ($veiculos) use (&$linhas, $campos) {
            foreach ($veiculos as $v) {
                $linhas[] = array_map(fn ($c) => $v->valorFormatado($c), array_keys($campos));
            }
        });

        return $linhas;
    }

    /** Gera .xlsx temporário e devolve o caminho */
    public function gerarXlsx(array $linhas, string $titulo = 'Veículos'): string
    {
        $planilha = new Spreadsheet();
        $aba = $planilha->getActiveSheet();
        $aba->setTitle(mb_substr($titulo, 0, 31));
        $aba->fromArray($linhas, null, 'A1', true);
        $aba->getStyle('1:1')->getFont()->setBold(true);
        $aba->freezePane('A2');
        foreach ($aba->getColumnIterator() as $col) {
            $aba->getColumnDimension($col->getColumnIndex())->setAutoSize(true);
        }

        $caminho = tempnam(sys_get_temp_dir(), 'exp').'.xlsx';
        (new Xlsx($planilha))->save($caminho);

        return $caminho;
    }
}
