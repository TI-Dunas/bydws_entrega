<?php

namespace App\Services;

use App\Models\Setting;
use Google\Client;
use Google\Service\Drive;
use Google\Service\Drive\DriveFile;
use Google\Service\Sheets;
use Google\Service\Sheets\ClearValuesRequest;
use Google\Service\Sheets\ValueRange;
use Illuminate\Support\Facades\Storage;
use RuntimeException;

/**
 * Integração com Google Drive / Sheets usando conta de serviço.
 * A pasta e a planilha precisam ser compartilhadas com o e-mail da conta de serviço.
 */
class GoogleDriveService
{
    public const CREDENCIAL = 'private/google/service-account.json';

    private ?Client $client = null;

    public function configurado(): bool
    {
        return Storage::disk('local')->exists(self::CREDENCIAL);
    }

    public function emailContaServico(): ?string
    {
        if (! $this->configurado()) {
            return null;
        }
        return json_decode(Storage::disk('local')->get(self::CREDENCIAL), true)['client_email'] ?? null;
    }

    private function client(): Client
    {
        if (! $this->configurado()) {
            throw new RuntimeException('Envie o arquivo JSON da conta de serviço do Google.');
        }
        if (! $this->client) {
            $this->client = new Client();
            $this->client->setApplicationName(config('app.name'));
            $this->client->setAuthConfig(Storage::disk('local')->path(self::CREDENCIAL));
            $this->client->setScopes([Drive::DRIVE, Sheets::SPREADSHEETS]);
        }
        return $this->client;
    }

    private function drive(): Drive
    {
        return new Drive($this->client());
    }

    private function sheets(): Sheets
    {
        return new Sheets($this->client());
    }

    public function listarArquivos(?string $pastaId = null): array
    {
        $pastaId = $pastaId ?: Setting::get('drive.pasta_id');
        if (! $pastaId) {
            throw new RuntimeException('Informe o ID da pasta do Google Drive.');
        }
        $res = $this->drive()->files->listFiles([
            'q'                         => sprintf("'%s' in parents and trashed = false", addslashes($pastaId)),
            'fields'                    => 'files(id,name,mimeType,modifiedTime,webViewLink)',
            'orderBy'                   => 'modifiedTime desc',
            'pageSize'                  => 100,
            'supportsAllDrives'         => true,
            'includeItemsFromAllDrives' => true,
        ]);

        return array_map(fn ($f) => [
            'id'         => $f->getId(),
            'nome'       => $f->getName(),
            'tipo'       => $f->getMimeType(),
            'modificado' => $f->getModifiedTime(),
            'link'       => $f->getWebViewLink(),
        ], $res->getFiles());
    }

    /** Envia arquivo local para a pasta configurada. Recomendado: pasta em Drive compartilhado. */
    public function enviarArquivo(string $caminho, string $nome, ?string $pastaId = null): array
    {
        $pastaId = $pastaId ?: Setting::get('drive.pasta_id');
        if (! $pastaId) {
            throw new RuntimeException('Informe o ID da pasta do Google Drive.');
        }
        $meta = new DriveFile(['name' => $nome, 'parents' => [$pastaId]]);
        $f = $this->drive()->files->create($meta, [
            'data'              => file_get_contents($caminho),
            'mimeType'          => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'uploadType'        => 'multipart',
            'fields'            => 'id,name,webViewLink',
            'supportsAllDrives' => true,
        ]);

        return ['id' => $f->getId(), 'nome' => $f->getName(), 'link' => $f->getWebViewLink()];
    }

    /** Substitui o conteúdo da aba da planilha Google pelos dados informados */
    public function escreverPlanilha(array $linhas, ?string $planilhaId = null, ?string $aba = null): int
    {
        [$planilhaId, $aba] = $this->alvo($planilhaId, $aba);
        $svc = $this->sheets();
        $svc->spreadsheets_values->clear($planilhaId, $aba, new ClearValuesRequest());
        $svc->spreadsheets_values->update($planilhaId, $aba.'!A1', new ValueRange(['values' => $linhas]), ['valueInputOption' => 'USER_ENTERED']);

        return max(0, count($linhas) - 1);
    }

    public function lerPlanilha(?string $planilhaId = null, ?string $aba = null): array
    {
        [$planilhaId, $aba] = $this->alvo($planilhaId, $aba);
        $res = $this->sheets()->spreadsheets_values->get($planilhaId, $aba, ['valueRenderOption' => 'FORMATTED_VALUE']);

        return $res->getValues() ?? [];
    }

    /** Lê um arquivo da pasta (Google Sheets ou .xlsx) e devolve as linhas */
    public function lerArquivoDrive(string $arquivoId, PlanilhaService $planilhas): array
    {
        $f = $this->drive()->files->get($arquivoId, ['fields' => 'id,name,mimeType', 'supportsAllDrives' => true]);

        if ($f->getMimeType() === 'application/vnd.google-apps.spreadsheet') {
            $meta = $this->sheets()->spreadsheets->get($arquivoId);
            $primeiraAba = $meta->getSheets()[0]->getProperties()->getTitle();
            return $this->lerPlanilha($arquivoId, $primeiraAba);
        }

        $resp = $this->drive()->files->get($arquivoId, ['alt' => 'media', 'supportsAllDrives' => true]);
        $tmp = tempnam(sys_get_temp_dir(), 'drv').'.xlsx';
        file_put_contents($tmp, (string) $resp->getBody());
        try {
            return $planilhas->lerArquivo($tmp);
        } finally {
            @unlink($tmp);
        }
    }

    private function alvo(?string $planilhaId, ?string $aba): array
    {
        $planilhaId = $planilhaId ?: Setting::get('drive.planilha_id');
        $aba = $aba ?: Setting::get('drive.aba', 'Veiculos');
        if (! $planilhaId) {
            throw new RuntimeException('Informe o ID da planilha Google.');
        }
        return [$planilhaId, $aba];
    }
}
