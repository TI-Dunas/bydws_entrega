<?php

namespace App\Http\Controllers;

use App\Models\Perfil;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/** Perfis personalizáveis: áreas liberadas e nível de acesso campo a campo */
class PerfilController extends Controller
{
    public function index()
    {
        return view('perfis.index', [
            'perfis' => Perfil::withCount('usuarios')->orderByDesc('sistema')->orderBy('nome')->get(),
        ]);
    }

    public function create(Request $request)
    {
        $perfil = new Perfil(['modulos' => ['dashboard', 'veiculos.ver'], 'campos' => []]);

        // "Duplicar": parte das permissões de um perfil existente
        if ($base = Perfil::where('slug', $request->input('base'))->first()) {
            $perfil->modulos = $base->ehAdmin() ? Perfil::todosModulos() : $base->modulos;
            $perfil->campos = $base->ehAdmin()
                ? array_fill_keys(array_keys(Perfil::todosCampos()), 'editar')
                : $base->campos;
            $perfil->nome = 'Cópia de '.$base->nome;
            $perfil->descricao = $base->descricao;
        }

        return view('perfis.form', ['perfil' => $perfil]);
    }

    public function store(Request $request)
    {
        $d = $this->validar($request);
        $slug = Str::slug($d['nome']) ?: 'perfil';
        $base = $slug;
        for ($i = 2; $slug === 'admin' || Perfil::where('slug', $slug)->exists(); $i++) {
            $slug = $base.'-'.$i;
        }
        Perfil::create($d + ['slug' => $slug]);

        return redirect()->route('perfis.index')->with('ok', "Perfil {$d['nome']} criado.");
    }

    public function edit(Perfil $perfil)
    {
        abort_if($perfil->sistema, 403, 'O perfil de administração não pode ser alterado.');

        return view('perfis.form', ['perfil' => $perfil]);
    }

    public function update(Request $request, Perfil $perfil)
    {
        abort_if($perfil->sistema, 403, 'O perfil de administração não pode ser alterado.');
        $perfil->update($this->validar($request, $perfil));

        return redirect()->route('perfis.index')->with('ok', "Perfil {$perfil->nome} salvo.");
    }

    public function destroy(Perfil $perfil)
    {
        abort_if($perfil->sistema, 403, 'O perfil de administração não pode ser excluído.');
        if ($n = $perfil->usuarios()->count()) {
            return back()->with('erro', "O perfil {$perfil->nome} tem {$n} usuário(s). Mude o perfil deles antes de excluir.");
        }
        $perfil->delete();

        return back()->with('ok', 'Perfil excluído.');
    }

    private function validar(Request $request, ?Perfil $perfil = null): array
    {
        $campos = array_keys(Perfil::todosCampos());
        $d = $request->validate([
            'nome'      => ['required', 'string', 'max:80', Rule::unique('perfis', 'nome')->ignore($perfil?->id)],
            'descricao' => 'nullable|string|max:255',
            'modulos'   => 'nullable|array',
            'modulos.*' => ['string', Rule::in(Perfil::todosModulos())],
            'campos'    => 'nullable|array',
            'campos.*'  => ['string', Rule::in(array_keys(Perfil::NIVEIS))],
        ]);

        $modulos = array_values(array_unique($d['modulos'] ?? []));
        $niveis = [];
        foreach ($campos as $c) {
            $niveis[$c] = $d['campos'][$c] ?? 'ler';
        }
        // Coerência: editar veículos exige ver veículos; chassi nunca fica oculto
        if (in_array('editar', $niveis, true) || array_intersect(['veiculos.criar', 'veiculos.excluir', 'veiculos.vinculos'], $modulos)) {
            $modulos[] = 'veiculos.ver';
        }
        if ($niveis['chassi'] === 'oculto') {
            $niveis['chassi'] = 'ler';
        }

        return [
            'nome'      => $d['nome'],
            'descricao' => $d['descricao'] ?? null,
            'modulos'   => array_values(array_unique($modulos)),
            'campos'    => $niveis,
        ];
    }
}
