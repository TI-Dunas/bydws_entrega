<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Models\Setting;
use App\Models\SyncLog;
use App\Models\Vendedor;
use App\Services\GlpiService;
use Illuminate\Http\Request;

/** Aba GLPI: conexão via token e sincronização de vendedores (usuários OU=CE) */
class GlpiController extends Controller
{
    public function index()
    {
        return view('glpi.index', [
            'cfg' => [
                'url'            => Setting::get('glpi.url'),
                'ou'             => Setting::get('glpi.ou', 'CE'),
                'verificar_ssl'  => Setting::get('glpi.verificar_ssl', '1'),
                'loja_padrao_id' => Setting::get('glpi.loja_padrao_id'),
                'auto'           => Setting::get('glpi.auto', '0'),
                'tem_app_token'  => (bool) Setting::get('glpi.app_token'),
                'tem_user_token' => (bool) Setting::get('glpi.user_token'),
            ],
            'lojas'      => Loja::orderBy('nome')->get(),
            'vendedores' => Vendedor::with('loja')->orderByRaw("status = 'Ativo' desc")->orderBy('nome')->paginate(30),
            'logs'       => SyncLog::where('origem', 'glpi')->latest()->limit(10)->get(),
        ]);
    }

    public function salvar(Request $request)
    {
        $d = $request->validate([
            'url'            => 'required|url',
            'app_token'      => 'nullable|string|max:255',
            'user_token'     => 'nullable|string|max:255',
            'ou'             => 'required|string|max:100',
            'loja_padrao_id' => 'nullable|exists:lojas,id',
        ]);
        Setting::put('glpi.url', $d['url']);
        Setting::put('glpi.ou', $d['ou']);
        Setting::put('glpi.loja_padrao_id', $d['loja_padrao_id'] ?? null);
        Setting::put('glpi.verificar_ssl', $request->boolean('verificar_ssl') ? '1' : '0');
        Setting::put('glpi.auto', $request->boolean('auto') ? '1' : '0');
        // Tokens só são trocados quando preenchidos (campo vazio mantém o atual)
        foreach (['app_token', 'user_token'] as $t) {
            if (! empty($d[$t])) {
                Setting::put('glpi.'.$t, $d[$t]);
            }
        }

        return back()->with('ok', 'Configuração do GLPI salva.');
    }

    public function testar(GlpiService $glpi)
    {
        try {
            $msg = $glpi->testar();
            SyncLog::registrar('glpi', 'Teste de conexão', true, $msg);
            return back()->with('ok', $msg);
        } catch (\Throwable $e) {
            SyncLog::registrar('glpi', 'Teste de conexão', false, $e->getMessage());
            return back()->with('erro', $e->getMessage());
        }
    }

    public function sincronizar(GlpiService $glpi)
    {
        try {
            $r = $glpi->sincronizarVendedores();
            $msg = "{$r['total']} usuários na OU: {$r['novos']} novos, {$r['atualizados']} atualizados, {$r['inativados']} inativados.";
            SyncLog::registrar('glpi', 'Sincronização de vendedores', true, $msg);
            return back()->with('ok', $msg);
        } catch (\Throwable $e) {
            SyncLog::registrar('glpi', 'Sincronização de vendedores', false, $e->getMessage());
            return back()->with('erro', $e->getMessage());
        }
    }

    /** Ajuste manual de loja/CRM/status do vendedor */
    public function atualizarVendedor(Request $request, Vendedor $vendedor)
    {
        $vendedor->update($request->validate([
            'loja_id' => 'nullable|exists:lojas,id',
            'crm'     => 'nullable|string|max:255',
            'status'  => 'required|in:Ativo,Inativo',
        ]));

        return back()->with('ok', "Vendedor {$vendedor->nome} atualizado.");
    }

    public function criarVendedor(Request $request)
    {
        Vendedor::create($request->validate([
            'nome'    => 'required|string|max:255',
            'loja_id' => 'nullable|exists:lojas,id',
            'crm'     => 'nullable|string|max:255',
        ]) + ['status' => 'Ativo', 'origem' => 'manual']);

        return back()->with('ok', 'Vendedor cadastrado.');
    }
}
