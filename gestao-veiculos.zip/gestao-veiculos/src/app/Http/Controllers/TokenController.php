<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

/** Lojas e tokens Bearer da API (seção 1) */
class TokenController extends Controller
{
    public function index()
    {
        return view('tokens.index', [
            'lojas'  => Loja::withCount('veiculos')->orderBy('codigo')->get(),
            'tokens' => PersonalAccessToken::where('tokenable_type', Loja::class)->latest()->get(),
            'novo'   => session('novo_token'),
        ]);
    }

    public function criarLoja(Request $request)
    {
        Loja::create($request->validate([
            'codigo' => 'required|string|max:30|unique:lojas,codigo',
            'nome'   => 'required|string|max:255',
        ]));

        return back()->with('ok', 'Loja cadastrada.');
    }

    public function gerar(Request $request)
    {
        $d = $request->validate([
            'loja_id'     => 'required|exists:lojas,id',
            'nome'        => 'required|string|max:100',
            'permissao'   => 'required|in:leitura,escrita',
            'expira_dias' => 'nullable|integer|min:1|max:3650',
        ]);
        $abilities = ['read'];
        if ($d['permissao'] === 'escrita') {
            $abilities[] = 'write';
        }
        if ($request->boolean('todas_lojas')) {
            $abilities[] = 'all-lojas';
        }
        $expira = ! empty($d['expira_dias']) ? now()->addDays((int) $d['expira_dias']) : null;
        $token = Loja::find($d['loja_id'])->createToken($d['nome'], $abilities, $expira);

        return back()->with('novo_token', $token->plainTextToken);
    }

    public function revogar(int $id)
    {
        PersonalAccessToken::where('tokenable_type', Loja::class)->whereKey($id)->delete();

        return back()->with('ok', 'Token revogado.');
    }
}
