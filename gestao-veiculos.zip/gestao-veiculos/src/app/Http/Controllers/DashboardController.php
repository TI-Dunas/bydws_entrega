<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Models\Veiculo;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;

/** Dashboard de entregas por período (base: DATA DE ENTREGA) */
class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $inicio = Carbon::parse($request->input('inicio', now()->startOfMonth()->toDateString()))->startOfDay();
        $fim = Carbon::parse($request->input('fim', now()->endOfMonth()->toDateString()))->endOfDay();
        if ($fim->lt($inicio)) {
            [$inicio, $fim] = [$fim->copy()->startOfDay(), $inicio->copy()->endOfDay()];
        }
        $agrupar = in_array($request->input('agrupar'), ['dia', 'semana', 'mes'], true) ? $request->input('agrupar') : 'dia';
        $lojaId = $user->loja_id ?: ($request->integer('loja_id') ?: null);

        $veiculos = Veiculo::with('vendedor:id,nome')
            ->daLoja($lojaId)
            ->whereBetween('data_entrega', [$inicio->toDateString(), $fim->toDateString()])
            ->get(['id', 'vendedor_id', 'consultor', 'modelo', 'chassi', 'placa', 'cliente', 'data_entrega', 'hora_entrega',
                'entregue', 'periodo_entrega', 'nps', 'qualidade_entrega', 'status_placa', 'status_veiculo', 'status_agendamento']);

        $total = $veiculos->count();
        $entregues = $veiculos->where('entregue', true)->count();
        $hoje = now()->startOfDay();
        $atrasadas = $veiculos->filter(fn ($v) => ! $v->entregue && $v->data_entrega->lt($hoje))->count();

        $notas = $veiculos->pluck('nps')->filter(fn ($n) => $n !== null);
        $nps = null;
        if ($notas->count()) {
            $promotores = $notas->filter(fn ($n) => $n >= 9)->count();
            $detratores = $notas->filter(fn ($n) => $n <= 6)->count();
            $nps = (int) round(($promotores - $detratores) / $notas->count() * 100);
        }

        // Série temporal
        $chave = fn (Carbon $d) => match ($agrupar) {
            'semana' => $d->copy()->startOfWeek()->format('Y-m-d'),
            'mes'    => $d->format('Y-m'),
            default  => $d->format('Y-m-d'),
        };
        $rotulo = fn (string $k) => match ($agrupar) {
            'semana' => 'Sem. '.Carbon::parse($k)->format('d/m'),
            'mes'    => Carbon::createFromFormat('Y-m', $k)->locale('pt_BR')->translatedFormat('M/y'),
            default  => Carbon::parse($k)->format('d/m'),
        };
        $serie = [];
        foreach (CarbonPeriod::create($inicio, $fim) as $d) {
            $serie[$chave($d)] ??= ['entregues' => 0, 'pendentes' => 0];
        }
        foreach ($veiculos as $v) {
            $k = $chave($v->data_entrega);
            $serie[$k][$v->entregue ? 'entregues' : 'pendentes']++;
        }

        $porPeriodo = $veiculos->groupBy(fn ($v) => $v->periodo_entrega ?: 'Não informado')->map->count()->sortDesc();
        $porStatusPlaca = $veiculos->groupBy(fn ($v) => $v->status_placa ?: 'Não informado')->map->count()->sortDesc();

        $porConsultor = $veiculos->groupBy(fn ($v) => $v->vendedor?->nome ?? ($v->consultor ?: 'Sem consultor'))
            ->map(fn ($g, $nome) => [
                'nome'      => $nome,
                'total'     => $g->count(),
                'entregues' => $g->where('entregue', true)->count(),
                'nps'       => $g->pluck('nps')->filter(fn ($n) => $n !== null)->avg(),
            ])->sortByDesc('total')->values();

        $proximas = $veiculos->where('entregue', false)
            ->sortBy(fn ($v) => $v->data_entrega->format('Y-m-d').' '.($v->hora_entrega ?? '99'))
            ->take(12);

        return view('dashboard', [
            'inicio' => $inicio, 'fim' => $fim, 'agrupar' => $agrupar, 'lojaId' => $lojaId,
            'lojas' => $user->loja_id ? collect() : Loja::orderBy('nome')->get(),
            'total' => $total, 'entregues' => $entregues, 'atrasadas' => $atrasadas, 'nps' => $nps,
            'avaliacoes' => $notas->count(),
            'serie' => [
                'rotulos'   => array_map($rotulo, array_keys($serie)),
                'entregues' => array_column($serie, 'entregues'),
                'pendentes' => array_column($serie, 'pendentes'),
            ],
            'porPeriodo' => $porPeriodo, 'porStatusPlaca' => $porStatusPlaca,
            'porConsultor' => $porConsultor, 'proximas' => $proximas,
        ]);
    }
}
