<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Models\Perfil;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UsuarioController extends Controller
{
    public function index()
    {
        return view('usuarios.index', [
            'usuarios' => User::with('loja')->orderBy('name')->get(),
            'lojas'    => Loja::orderBy('nome')->get(),
            'perfis'   => Perfil::orderByDesc('sistema')->orderBy('nome')->get(),
        ]);
    }

    public function store(Request $request)
    {
        if ($request->input('perfil') === 'admin' && ! $request->user()->isAdmin()) {
            return back()->with('erro', 'Só administradores podem criar outros administradores.');
        }
        User::create($request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
            'perfil'   => 'required|exists:perfis,slug',
            'loja_id'  => 'nullable|exists:lojas,id',
        ]));

        return back()->with('ok', 'Usuário criado.');
    }

    public function update(Request $request, User $usuario)
    {
        $d = $request->validate([
            'perfil'   => 'required|exists:perfis,slug',
            'loja_id'  => 'nullable|exists:lojas,id',
            'password' => 'nullable|string|min:8',
        ]);
        if (! $request->user()->isAdmin() && ($usuario->isAdmin() || $d['perfil'] === 'admin')) {
            return back()->with('erro', 'Só administradores podem alterar administradores ou conceder esse perfil.');
        }
        if ($usuario->is($request->user()) && $usuario->isAdmin() && $d['perfil'] !== 'admin') {
            return back()->with('erro', 'Você não pode remover o próprio perfil de administração.');
        }
        if (empty($d['password'])) {
            unset($d['password']);
        }
        $usuario->update($d);

        return back()->with('ok', "Usuário {$usuario->name} atualizado.");
    }

    public function destroy(Request $request, User $usuario)
    {
        abort_if($usuario->is($request->user()), 422, 'Você não pode excluir o próprio usuário.');
        abort_if($usuario->isAdmin() && ! $request->user()->isAdmin(), 403, 'Só administradores podem excluir administradores.');
        $usuario->delete();

        return back()->with('ok', 'Usuário excluído.');
    }
}
