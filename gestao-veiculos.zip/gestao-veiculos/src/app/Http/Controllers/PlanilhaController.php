<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Models\SyncLog;
use App\Models\Vendedor;
use App\Models\Veiculo;
use App\Services\PlanilhaService;
use Illuminate\Http\Request;

/** Importação / exportação de planilhas (seção 3) */
class PlanilhaController extends Controller
{
    public function index(Request $request, PlanilhaService $planilhas)
    {
        return view('planilhas.index', [
            'lojas'      => Loja::orderBy('nome')->get(),
            'vendedores' => Vendedor::ativos()->orderBy('nome')->get(['id', 'nome', 'loja_id']),
            'cabecalhos' => $planilhas->cabecalhosHomologados(),
            'resultado'  => session('resultado'),
            'logs'       => SyncLog::where('origem', 'importacao')->latest()->limit(10)->get(),
        ]);
    }

    public function importar(Request $request, PlanilhaService $planilhas)
    {
        $request->validate([
            'arquivo'     => 'required|file|mimes:xlsx,xls|max:51200',
            'loja_id'     => 'required|exists:lojas,id',
            'vendedor_id' => 'nullable|exists:vendedores,id',
        ]);
        $loja = Loja::findOrFail($request->input('loja_id'));
        $vendedor = $request->filled('vendedor_id') ? Vendedor::find($request->input('vendedor_id')) : null;

        $linhas = $planilhas->lerArquivo($request->file('arquivo')->getRealPath());
        $res = $planilhas->importar($linhas, $loja, $vendedor);

        SyncLog::registrar('importacao', 'Planilha '.$request->file('arquivo')->getClientOriginalName(), $res['ok'],
            $res['ok'] ? "{$res['criados']} criados, {$res['atualizados']} atualizados, loja {$loja->codigo}" : implode(' ', $res['erros']));

        return back()->with('resultado', $res);
    }

    public function exportar(Request $request, PlanilhaService $planilhas)
    {
        $user = $request->user();
        $lojaId = $user->loja_id ?: ($request->integer('loja_id') ?: null);
        $query = Veiculo::query()->daLoja($lojaId)
            ->when($request->input('inicio'), fn ($q, $d) => $q->where('data_entrega', '>=', $d))
            ->when($request->input('fim'), fn ($q, $d) => $q->where('data_entrega', '<=', $d));

        $caminho = $planilhas->gerarXlsx($planilhas->linhasExportacao($query, true, $user->camposVisiveis()));

        return response()->download($caminho, 'veiculos_'.now()->format('Ymd_His').'.xlsx')->deleteFileAfterSend();
    }

    public function modelo(PlanilhaService $planilhas)
    {
        $caminho = $planilhas->gerarXlsx([$planilhas->cabecalhosHomologados()], 'Modelo');

        return response()->download($caminho, 'modelo_importacao_veiculos.xlsx')->deleteFileAfterSend();
    }
}
