<?php

namespace App\Http\Controllers\Api;

use App\Services\ConsultaService;
use Illuminate\Http\Request;

class ConsultaApiController extends ApiController
{
    public function __construct(private ConsultaService $consulta)
    {
    }

    public function vendedores(Request $request)
    {
        $loja = $this->lojaEscopo($request);
        $p = $this->consulta->vendedores($loja?->id, $request->only(['status', 'nome']))->paginate($this->porPagina($request));

        return $p->through(fn ($v) => [
            'id_vendedor'        => $v->id,
            'consultor'          => $v->nome,
            'crm'                => $v->crm,
            'status_do_vendedor' => $v->status,
            'codigo_loja'        => $v->loja?->codigo,
            'glpi_id'            => $v->glpi_id,
        ]);
    }

    public function clientes(Request $request)
    {
        $loja = $this->lojaEscopo($request);
        $p = $this->consulta->clientes($loja?->id, $request->only(['cpf_cnpj', 'nome']))->paginate($this->porPagina($request));

        return $p->through(fn ($c) => [
            'id'                  => $c->id,
            'cliente'             => $c->nome,
            'contato'             => $c->contato,
            'cpf_cnpj'            => $c->cpf_cnpj,
            'codigo_loja'         => $c->loja?->codigo,
            'historico_de_compras' => $c->compras->map(fn ($v) => [
                'modelo'       => $v->modelo,
                'chassi'       => $v->chassi,
                'placa'        => $v->placa,
                'faturamento'  => $v->faturamento?->toDateString(),
                'data_entrega' => $v->data_entrega?->toDateString(),
                'entregue'     => $v->entregue,
            ]),
        ]);
    }

    public function carros(Request $request)
    {
        $loja = $this->lojaEscopo($request);
        $completo = $request->boolean('completo');
        $p = $this->consulta->carros($loja?->id, $request->only(['chassi', 'modelo', 'placa']))->paginate($this->porPagina($request));

        return $p->through(function ($v) use ($completo) {
            $base = [
                'id'                => $v->id,
                'modelo'            => $v->modelo,
                'chassi'            => $v->chassi,
                'modalidade'        => $v->modalidade,
                'status_do_veiculo' => $v->status_veiculo,
                'placa'             => $v->placa,
                'codigo_loja'       => $v->loja?->codigo,
            ];
            if ($completo) {
                foreach (array_keys(config('veiculos.campos')) as $c) {
                    $base['campos'][$c] = $v->valorFormatado($c);
                }
                $base['id_vendedor'] = $v->vendedor_id;
            }
            return $base;
        });
    }

    private function porPagina(Request $request): int
    {
        return min(200, max(1, $request->integer('por_pagina', 50)));
    }
}
