<?php

namespace App\Http\Controllers\Api;

use App\Models\Loja;
use App\Models\SyncLog;
use App\Models\Vendedor;
use App\Models\Veiculo;
use App\Services\PlanilhaService;
use Illuminate\Http\Request;

class PlanilhaApiController extends ApiController
{
    public function importar(Request $request, PlanilhaService $planilhas)
    {
        $request->validate([
            'arquivo'     => 'required|file|mimes:xlsx,xls|max:51200',
            'vendedor_id' => 'nullable|integer|exists:vendedores,id',
        ]);
        $loja = $this->lojaEscopo($request) ?? $request->user();
        $vendedor = $request->filled('vendedor_id') ? Vendedor::find($request->input('vendedor_id')) : null;
        abort_if($vendedor && $vendedor->loja_id && $vendedor->loja_id !== $loja->id, 422, 'Vendedor de outra loja.');

        $res = $planilhas->importar($planilhas->lerArquivo($request->file('arquivo')->getRealPath()), $loja, $vendedor);
        SyncLog::registrar('importacao', 'API: '.$request->file('arquivo')->getClientOriginalName(), $res['ok'],
            $res['ok'] ? "{$res['criados']} criados, {$res['atualizados']} atualizados, loja {$loja->codigo}" : implode(' ', $res['erros']));

        return response()->json($res, $res['ok'] ? 200 : 422);
    }

    public function exportar(Request $request, PlanilhaService $planilhas)
    {
        $loja = $this->lojaEscopo($request);
        $caminho = $planilhas->gerarXlsx($planilhas->linhasExportacao(Veiculo::query()->daLoja($loja?->id)));

        return response()->download($caminho, 'veiculos_'.($loja?->codigo ?? 'todas').'.xlsx')->deleteFileAfterSend();
    }
}
