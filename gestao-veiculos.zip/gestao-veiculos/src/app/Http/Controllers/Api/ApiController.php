<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Loja;
use Illuminate\Http\Request;

abstract class ApiController extends Controller
{
    /**
     * Resolve o escopo de loja a partir do token.
     * Token comum: sempre a loja dona do token (codigo_loja, se enviado, deve coincidir).
     * Token com 'all-lojas': codigo_loja opcional filtra; ausente = todas.
     */
    protected function lojaEscopo(Request $request): ?Loja
    {
        /** @var Loja $loja */
        $loja = $request->user();
        $codigo = $request->input('codigo_loja');

        if ($loja->tokenCan('all-lojas')) {
            return $codigo ? Loja::where('codigo', $codigo)->firstOr(fn () => abort(404, 'Código de loja não encontrado.')) : null;
        }
        abort_if($codigo && $codigo !== $loja->codigo, 403, 'Este token não tem acesso à loja informada.');

        return $loja;
    }
}
