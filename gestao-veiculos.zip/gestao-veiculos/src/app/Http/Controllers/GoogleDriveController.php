<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Models\Setting;
use App\Models\SyncLog;
use App\Models\Veiculo;
use App\Services\GoogleDriveService;
use App\Services\PlanilhaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/** Aba de sincronização com o Google Drive / Google Sheets */
class GoogleDriveController extends Controller
{
    public function index(GoogleDriveService $drive)
    {
        $arquivos = [];
        $erroLista = null;
        if ($drive->configurado() && Setting::get('drive.pasta_id')) {
            try {
                $arquivos = $drive->listarArquivos();
            } catch (\Throwable $e) {
                $erroLista = $e->getMessage();
            }
        }

        return view('drive.index', [
            'cfg' => [
                'pasta_id'    => Setting::get('drive.pasta_id'),
                'planilha_id' => Setting::get('drive.planilha_id'),
                'aba'         => Setting::get('drive.aba', 'Veiculos'),
                'loja_id'     => Setting::get('drive.loja_id'),
                'auto'        => Setting::get('drive.auto', '0'),
            ],
            'email'     => $drive->emailContaServico(),
            'arquivos'  => $arquivos,
            'erroLista' => $erroLista,
            'lojas'     => Loja::orderBy('nome')->get(),
            'resultado' => session('resultado'),
            'logs'      => SyncLog::where('origem', 'drive')->latest()->limit(10)->get(),
        ]);
    }

    public function salvar(Request $request)
    {
        $d = $request->validate([
            'credencial'  => 'nullable|file|max:64',
            'pasta_id'    => 'nullable|string|max:255',
            'planilha_id' => 'nullable|string|max:255',
            'aba'         => 'required|string|max:100',
            'loja_id'     => 'nullable|exists:lojas,id',
        ]);

        if ($request->hasFile('credencial')) {
            $json = json_decode(file_get_contents($request->file('credencial')->getRealPath()), true);
            if (($json['type'] ?? null) !== 'service_account' || empty($json['client_email'])) {
                return back()->with('erro', 'O arquivo enviado não é uma credencial de conta de serviço do Google.');
            }
            Storage::disk('local')->put(GoogleDriveService::CREDENCIAL, json_encode($json));
        }
        Setting::put('drive.pasta_id', $this->extrairId($d['pasta_id'] ?? null));
        Setting::put('drive.planilha_id', $this->extrairId($d['planilha_id'] ?? null));
        Setting::put('drive.aba', $d['aba']);
        Setting::put('drive.loja_id', $d['loja_id'] ?? null);
        Setting::put('drive.auto', $request->boolean('auto') ? '1' : '0');

        return back()->with('ok', 'Configuração do Google Drive salva.');
    }

    /** Atualiza a planilha Google com todos os veículos (sistema -> Sheets) */
    public function enviarPlanilha(GoogleDriveService $drive, PlanilhaService $planilhas)
    {
        return $this->executar('Atualizar planilha Google', function () use ($drive, $planilhas) {
            $lojaId = Setting::get('drive.loja_id');
            $n = $drive->escreverPlanilha($planilhas->linhasExportacao(Veiculo::query()->daLoja($lojaId ? (int) $lojaId : null)));
            return "{$n} veículos enviados para a planilha.";
        });
    }

    /** Gera .xlsx e envia para a pasta */
    public function enviarArquivo(GoogleDriveService $drive, PlanilhaService $planilhas)
    {
        return $this->executar('Enviar .xlsx para a pasta', function () use ($drive, $planilhas) {
            $lojaId = Setting::get('drive.loja_id');
            $caminho = $planilhas->gerarXlsx($planilhas->linhasExportacao(Veiculo::query()->daLoja($lojaId ? (int) $lojaId : null)));
            try {
                $f = $drive->enviarArquivo($caminho, 'veiculos_'.now()->format('Ymd_His').'.xlsx');
            } finally {
                @unlink($caminho);
            }
            return "Arquivo {$f['nome']} enviado.";
        });
    }

    /** Importa da planilha Google configurada (Sheets -> sistema) */
    public function importarPlanilha(GoogleDriveService $drive, PlanilhaService $planilhas)
    {
        return $this->importar('Importar planilha Google', fn () => $drive->lerPlanilha(), $planilhas);
    }

    /** Importa um arquivo específico da pasta */
    public function importarArquivo(string $arquivoId, GoogleDriveService $drive, PlanilhaService $planilhas)
    {
        return $this->importar('Importar arquivo do Drive', fn () => $drive->lerArquivoDrive($arquivoId, $planilhas), $planilhas);
    }

    private function importar(string $acao, callable $ler, PlanilhaService $planilhas)
    {
        $loja = Loja::find(Setting::get('drive.loja_id'));
        if (! $loja) {
            return back()->with('erro', 'Escolha a loja de destino das importações do Drive e salve a configuração.');
        }
        try {
            $res = $planilhas->importar($ler(), $loja);
            SyncLog::registrar('drive', $acao, $res['ok'],
                $res['ok'] ? "{$res['criados']} criados, {$res['atualizados']} atualizados." : implode(' ', $res['erros']));
            return back()->with('resultado', $res);
        } catch (\Throwable $e) {
            SyncLog::registrar('drive', $acao, false, $e->getMessage());
            return back()->with('erro', $e->getMessage());
        }
    }

    private function executar(string $acao, callable $fn)
    {
        try {
            $msg = $fn();
            SyncLog::registrar('drive', $acao, true, $msg);
            return back()->with('ok', $msg);
        } catch (\Throwable $e) {
            SyncLog::registrar('drive', $acao, false, $e->getMessage());
            return back()->with('erro', $e->getMessage());
        }
    }

    /** Aceita o ID puro ou a URL completa do Drive/Sheets */
    private function extrairId(?string $v): ?string
    {
        if (! $v) {
            return null;
        }
        if (preg_match('~/(?:d|folders)/([a-zA-Z0-9_-]+)~', $v, $m)) {
            return $m[1];
        }
        return trim($v);
    }
}
