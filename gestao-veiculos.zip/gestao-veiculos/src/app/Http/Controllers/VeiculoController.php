<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Loja;
use App\Models\Vendedor;
use App\Models\Veiculo;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VeiculoController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $lojaId = $user->loja_id ?: ($request->integer('loja_id') ?: null);
        $busca = trim((string) $request->input('busca'));

        $veiculos = Veiculo::with(['loja', 'vendedor'])
            ->daLoja($lojaId)
            ->when($busca, fn ($q) => $q->where(fn ($w) => $w
                ->where('chassi', 'like', "%{$busca}%")->orWhere('modelo', 'like', "%{$busca}%")
                ->orWhere('cliente', 'like', "%{$busca}%")->orWhere('placa', 'like', "%{$busca}%")
                ->orWhere('consultor', 'like', "%{$busca}%")))
            ->when($request->filled('entregue'), fn ($q) => $q->where('entregue', $request->input('entregue') === '1'))
            ->when($request->input('status_placa'), fn ($q, $s) => $q->where('status_placa', $s))
            ->orderByRaw('data_entrega is null, data_entrega asc')
            ->paginate(25)->withQueryString();

        return view('veiculos.index', [
            'veiculos' => $veiculos,
            'lojas' => $user->loja_id ? collect() : Loja::orderBy('nome')->get(),
            'lojaId' => $lojaId,
        ]);
    }

    public function create(Request $request)
    {
        return view('veiculos.form', $this->dadosForm($request, new Veiculo(['loja_id' => $request->user()->loja_id])));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        $dados = $this->validar($request, $user->camposEditaveis(), null);
        $dados += $request->validate([
            'loja_id'     => 'required|exists:lojas,id',
            'vendedor_id' => 'nullable|exists:vendedores,id',
        ]);
        if ($user->loja_id) {
            $dados['loja_id'] = $user->loja_id; // usuário preso a uma loja só cadastra nela
        }
        $this->vincular($dados);
        $v = Veiculo::create($dados);

        return redirect()->route('veiculos.edit', $v)->with('ok', 'Veículo cadastrado.');
    }

    public function edit(Request $request, Veiculo $veiculo)
    {
        $this->autorizarLoja($request, $veiculo);

        return view('veiculos.form', $this->dadosForm($request, $veiculo));
    }

    public function update(Request $request, Veiculo $veiculo)
    {
        $this->autorizarLoja($request, $veiculo);
        $user = $request->user();

        // Só aceita os campos do(s) bloco(s) liberado(s) para o perfil
        $dados = $this->validar($request, $user->camposEditaveis(), $veiculo->id);
        if ($user->pode('veiculos.vinculos')) {
            $dados += $request->validate([
                'loja_id'     => 'required|exists:lojas,id',
                'vendedor_id' => 'nullable|exists:vendedores,id',
            ]);
            if ($user->loja_id) {
                $dados['loja_id'] = $user->loja_id;
            }
            $this->vincular($dados);
        }
        $veiculo->update($dados);

        return back()->with('ok', 'Alterações salvas.');
    }

    public function destroy(Veiculo $veiculo)
    {
        $veiculo->delete();

        return redirect()->route('veiculos.index')->with('ok', 'Veículo excluído.');
    }

    private function dadosForm(Request $request, Veiculo $veiculo): array
    {
        $user = $request->user();

        return [
            'veiculo'    => $veiculo,
            'editaveis'  => $user->camposEditaveis(),
            'lojas'      => Loja::orderBy('nome')->get(),
            'vendedores' => Vendedor::ativos()->orderBy('nome')->get(['id', 'nome', 'loja_id']),
        ];
    }

    private function validar(Request $request, array $campos, ?int $id): array
    {
        $defs = config('veiculos.campos') + config('veiculos.opcionais');
        $regras = [];
        foreach ($campos as $c) {
            $regras[$c] = match ($defs[$c]['tipo']) {
                'date' => ['nullable', 'date'],
                'time' => ['nullable', 'date_format:H:i'],
                'bool' => ['nullable', 'boolean'],
                'int'  => ['nullable', 'integer', 'between:0,10'],
                'text' => ['nullable', 'string', 'max:5000'],
                default => ['nullable', 'string', 'max:255'],
            };
        }
        if (isset($regras['chassi'])) {
            $regras['chassi'] = ['required', 'string', 'max:30', Rule::unique('veiculos', 'chassi')->ignore($id)];
        }
        $dados = $request->validate($regras);

        foreach ($campos as $c) {
            if ($defs[$c]['tipo'] === 'bool') {
                $dados[$c] = $request->boolean($c);
            }
        }
        foreach (['chassi', 'placa'] as $c) {
            if (! empty($dados[$c])) {
                $dados[$c] = strtoupper(trim($dados[$c]));
            }
        }
        return $dados;
    }

    /** Mantém consultor/cliente (texto) coerentes com os vínculos */
    private function vincular(array &$dados): void
    {
        if (! empty($dados['vendedor_id'])) {
            $dados['consultor'] = Vendedor::find($dados['vendedor_id'])->nome;
        }
        if (! empty($dados['cliente']) && ! empty($dados['loja_id'])) {
            $dados['cliente_id'] = Cliente::firstOrCreate(['loja_id' => $dados['loja_id'], 'nome' => trim($dados['cliente'])])->id;
        }
    }

    private function autorizarLoja(Request $request, Veiculo $veiculo): void
    {
        $lojaUsuario = $request->user()->loja_id;
        abort_if($lojaUsuario && $veiculo->loja_id !== $lojaUsuario, 403, 'Veículo de outra loja.');
    }
}
