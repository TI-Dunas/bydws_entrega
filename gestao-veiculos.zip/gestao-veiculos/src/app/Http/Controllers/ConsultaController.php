<?php

namespace App\Http\Controllers;

use App\Models\Loja;
use App\Services\ConsultaService;
use Illuminate\Http\Request;

/** Aba de consulta (seção 2): vendedor ativo, clientes e carros por Código da Loja */
class ConsultaController extends Controller
{
    public function index(Request $request, ConsultaService $consulta)
    {
        $user = $request->user();
        $aba = in_array($request->input('aba'), ['vendedores', 'clientes', 'carros'], true) ? $request->input('aba') : 'vendedores';

        $loja = $user->loja_id
            ? $user->loja
            : ($request->filled('codigo_loja') ? Loja::where('codigo', $request->input('codigo_loja'))->first() : null);
        $lojaInvalida = ! $user->loja_id && $request->filled('codigo_loja') && ! $loja;

        $filtros = $request->only(['nome', 'cpf_cnpj', 'chassi', 'modelo', 'placa']);
        $resultado = $lojaInvalida ? null : match ($aba) {
            'clientes' => $consulta->clientes($loja?->id, $filtros)->paginate(20)->withQueryString(),
            'carros'   => $consulta->carros($loja?->id, $filtros)->paginate(20)->withQueryString(),
            default    => $consulta->vendedores($loja?->id, $filtros)->paginate(20)->withQueryString(),
        };

        return view('consulta.index', [
            'aba' => $aba, 'resultado' => $resultado, 'loja' => $loja, 'lojaInvalida' => $lojaInvalida,
            'lojas' => $user->loja_id ? collect() : Loja::orderBy('codigo')->get(),
        ]);
    }
}
