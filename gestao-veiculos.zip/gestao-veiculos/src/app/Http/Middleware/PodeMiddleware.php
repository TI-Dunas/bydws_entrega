<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Uso: ->middleware('pode:glpi') ou 'pode:planilhas.importar,planilhas.exportar' (qualquer um) */
class PodeMiddleware
{
    public function handle(Request $request, Closure $next, string ...$modulos)
    {
        $user = $request->user();
        foreach ($modulos as $m) {
            if ($user?->pode($m)) {
                return $next($request);
            }
        }
        abort(403, 'Seu perfil não tem acesso a esta área.');
    }
}
