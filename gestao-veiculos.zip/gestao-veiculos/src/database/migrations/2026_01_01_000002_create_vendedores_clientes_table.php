<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('vendedores', function (Blueprint $t) {
            $t->id();
            $t->foreignId('loja_id')->nullable()->constrained('lojas')->nullOnDelete();
            $t->unsignedBigInteger('glpi_id')->nullable()->unique();
            $t->string('nome');
            $t->string('login')->nullable();
            $t->string('email')->nullable();
            $t->string('crm')->nullable();
            $t->string('status', 20)->default('Ativo');
            $t->string('origem', 20)->default('manual'); // manual | glpi
            $t->string('user_dn', 500)->nullable();
            $t->timestamp('sincronizado_em')->nullable();
            $t->timestamps();
            $t->index(['loja_id', 'status']);
        });

        Schema::create('clientes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('loja_id')->nullable()->constrained('lojas')->nullOnDelete();
            $t->string('nome');
            $t->string('cpf_cnpj', 20)->nullable()->index();
            $t->string('contato')->nullable();
            $t->timestamps();
            $t->index(['loja_id', 'nome']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('clientes');
        Schema::dropIfExists('vendedores');
    }
};
