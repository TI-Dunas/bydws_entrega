<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('perfis', function (Blueprint $t) {
            $t->id();
            $t->string('slug', 40)->unique();
            $t->string('nome', 80);
            $t->string('descricao')->nullable();
            $t->json('modulos')->nullable();   // áreas liberadas
            $t->json('campos')->nullable();    // campo => oculto | ler | editar
            $t->boolean('sistema')->default(false);
            $t->timestamps();
        });

        $todosCampos = array_keys(config('veiculos.campos') + config('veiculos.opcionais'));
        $grupoDe = array_map(fn ($d) => $d['grupo'], config('veiculos.campos') + config('veiculos.opcionais'));

        DB::table('perfis')->insert([
            'slug' => 'admin', 'nome' => 'Administração', 'sistema' => true,
            'descricao' => 'Acesso total. Não pode ser alterado nem excluído.',
            'modulos' => json_encode([]), 'campos' => json_encode([]),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        foreach (config('veiculos.perfis_iniciais') as $slug => $p) {
            $campos = [];
            foreach ($todosCampos as $c) {
                $campos[$c] = in_array($grupoDe[$c], $p['editar'], true) ? 'editar' : 'ler';
            }
            DB::table('perfis')->insert([
                'slug' => $slug, 'nome' => $p['nome'], 'descricao' => $p['descricao'], 'sistema' => false,
                'modulos' => json_encode($p['modulos']), 'campos' => json_encode($campos),
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        Schema::table('users', function (Blueprint $t) {
            $t->string('perfil', 40)->default('entrega')->change();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('perfis');
    }
};
