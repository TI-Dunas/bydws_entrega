<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $t) {
            $t->string('chave')->primary();
            $t->text('valor')->nullable();
            $t->timestamps();
        });

        Schema::create('sync_logs', function (Blueprint $t) {
            $t->id();
            $t->string('origem', 20);        // glpi | drive | importacao
            $t->string('acao', 60);
            $t->string('status', 10);        // ok | erro
            $t->text('mensagem')->nullable();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
            $t->index(['origem', 'created_at']);
        });

        if (! Schema::hasTable('personal_access_tokens')) {
            Schema::create('personal_access_tokens', function (Blueprint $t) {
                $t->id();
                $t->morphs('tokenable');
                $t->text('name');
                $t->string('token', 64)->unique();
                $t->text('abilities')->nullable();
                $t->timestamp('last_used_at')->nullable();
                $t->timestamp('expires_at')->nullable()->index();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('personal_access_tokens');
        Schema::dropIfExists('sync_logs');
        Schema::dropIfExists('settings');
    }
};
