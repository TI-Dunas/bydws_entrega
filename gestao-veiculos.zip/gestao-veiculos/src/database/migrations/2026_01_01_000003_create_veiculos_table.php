<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('veiculos', function (Blueprint $t) {
            $t->id();
            $t->foreignId('loja_id')->nullable()->constrained('lojas')->nullOnDelete();
            $t->foreignId('vendedor_id')->nullable()->constrained('vendedores')->nullOnDelete();
            $t->foreignId('cliente_id')->nullable()->constrained('clientes')->nullOnDelete();

            // Identificação e vendas
            $t->string('modelo')->nullable();
            $t->string('chassi', 30)->unique();
            $t->string('placa', 10)->nullable()->index();
            $t->string('modalidade')->nullable();
            $t->string('consultor')->nullable();
            $t->string('cliente')->nullable();
            $t->string('nota_fiscal')->nullable();
            $t->string('crm')->nullable();
            $t->string('campanha_bonus')->nullable();
            $t->date('faturamento')->nullable();
            $t->date('emplacamento')->nullable();

            // Acompanhamento / logística
            $t->date('data_solicitacao_carro')->nullable();
            $t->date('data_recebimento_documento')->nullable();
            $t->date('entrega_documentacao')->nullable();
            $t->string('status_emplacamento')->nullable();
            $t->date('prazo_emplacamento')->nullable();
            $t->date('data_entrega')->nullable()->index();
            $t->time('hora_entrega')->nullable();
            $t->string('vu')->nullable();
            $t->boolean('entregue')->default(false)->index();
            $t->string('localizacao')->nullable();

            // Documentação e placas
            $t->string('doc_emplacamento_consultor')->nullable();
            $t->date('entrega_despachante')->nullable();
            $t->string('status_placa')->nullable();
            $t->date('data_confeccao')->nullable();
            $t->string('status_veiculo')->nullable();

            // Pós-venda
            $t->string('status_agendamento')->nullable();
            $t->date('data_agendamento')->nullable();
            $t->time('hora_agendamento')->nullable();
            $t->string('responsavel_agendamento')->nullable();
            $t->string('qualidade_entrega')->nullable();
            $t->text('observacoes')->nullable();
            $t->unsignedTinyInteger('nps')->nullable();
            $t->string('periodo_entrega')->nullable();

            $t->timestamps();
            $t->index(['loja_id', 'data_entrega']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('veiculos');
    }
};
