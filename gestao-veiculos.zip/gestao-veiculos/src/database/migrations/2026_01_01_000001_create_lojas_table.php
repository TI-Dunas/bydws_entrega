<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('lojas', function (Blueprint $t) {
            $t->id();
            $t->string('codigo', 30)->unique();
            $t->string('nome');
            $t->boolean('ativa')->default(true);
            $t->timestamps();
        });

        Schema::table('users', function (Blueprint $t) {
            $t->string('perfil', 20)->default('entrega')->after('email');
            $t->foreignId('loja_id')->nullable()->after('perfil')->constrained('lojas')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->dropConstrainedForeignId('loja_id');
            $t->dropColumn('perfil');
        });
        Schema::dropIfExists('lojas');
    }
};
