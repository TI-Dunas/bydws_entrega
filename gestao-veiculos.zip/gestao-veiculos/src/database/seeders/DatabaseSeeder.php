<?php

namespace Database\Seeders;

use App\Models\Loja;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Loja::firstOrCreate(['codigo' => '001'], ['nome' => 'Matriz']);

        $email = env('ADMIN_EMAIL', 'admin@empresa.com.br');
        if (! User::where('email', $email)->exists()) {
            User::create([
                'name'     => env('ADMIN_NAME', 'Administrador'),
                'email'    => $email,
                'password' => Hash::make(env('ADMIN_PASSWORD', 'admin123')),
                'perfil'   => 'admin',
            ]);
        }
    }
}
