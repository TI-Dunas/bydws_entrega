# Gestão de Veículos: entregas, emplacamento e integrações

Sistema Laravel 12 + Nginx + MySQL em Docker, construído a partir da especificação técnica
de integração e consulta de dados da operação de veículos.

## Subir o ambiente

```bash
cp .env.example .env        # troque as senhas
docker compose up -d --build
```

Acesse `http://localhost:8080` com `ADMIN_EMAIL` / `ADMIN_PASSWORD` do `.env`.
No primeiro start o container `app` gera a `APP_KEY` (guardada no volume `storage`),
roda as migrações e cria o administrador e a loja `001 · Matriz`.

Containers: `nginx` (porta 8080), `app` (PHP-FPM 8.3), `scheduler` (sincronizações automáticas), `db` (MySQL 8.4).

## O que tem

| Área | Perfil | Descrição |
|---|---|---|
| Dashboard de entregas | todos | Período livre, agrupamento por dia/semana/mês, entregues × a entregar, datas vencidas, NPS, por período de entrega, status das placas, ranking por consultor, próximas entregas |
| Veículos | todos | Lista e ficha com os 33 campos em 4 blocos. **Administração** edita Identificação e vendas + Acompanhamento e logística (e pós-venda). **Entrega** edita Documentação e placas; os demais blocos aparecem somente leitura |
| Consulta | todos | Vendedores ativos, clientes (com histórico de compras) e carros, filtrados por código da loja |
| Importar e exportar | admin (exportar: todos) | `.xlsx` com validação estrita de cabeçalhos, upsert por chassi, vendedor em lote |
| GLPI e vendedores | admin | API REST do GLPI por App-Token + user_token; importa usuários cujo DN contém `OU=CE` (OU configurável) |
| Google Drive | admin | Conta de serviço; atualiza / importa Google Sheets, envia `.xlsx` para a pasta, importa arquivos da pasta |
| Lojas e tokens de API | admin | Tokens Bearer por loja (Sanctum), leitura ou escrita, opção “todas as lojas”, expiração |
| Usuários | admin | Cadastro de usuários, perfil e vínculo opcional a uma loja |
| Perfis | admin | Criar, editar, duplicar e excluir perfis: áreas liberadas e, campo a campo, Oculto / Leitura / Edição |

## Perfis personalizáveis

Em **Administração › Perfis** o administrador:

- cria perfis novos ou duplica um existente;
- escolhe as áreas liberadas (dashboard, veículos, cadastrar/excluir, trocar loja e vendedor, consulta, exportar, importar, GLPI, Drive, tokens, usuários);
- define cada um dos campos do veículo como **Oculto**, **Leitura** ou **Edição**, com atalhos para aplicar a um bloco inteiro.

O perfil **Administração** é fixo (acesso total) para ninguém ficar trancado fora do sistema.
Só administradores concedem ou retiram esse perfil. Campos ocultos também saem da exportação do usuário.
A instalação cria o perfil **Entrega** com o padrão da especificação (edita Documentação e placas).

O mapeamento campo ↔ cabeçalho da planilha e as sugestões de status ficam em `src/config/veiculos.php`.

## API

Todas as rotas exigem `Authorization: Bearer <TOKEN>`. O token pertence a uma loja e só vê os dados dela.

```
GET  /api/vendedores          ?codigo_loja &status=Ativo &nome
GET  /api/clientes            ?codigo_loja &cpf_cnpj &nome
GET  /api/carros              ?codigo_loja &chassi &modelo &placa &completo=1
GET  /api/veiculos/exportar   ?codigo_loja
POST /api/veiculos/importar   arquivo=@planilha.xlsx  vendedor_id (opcional)   [token com escrita]
```

## Configurar o GLPI

1. GLPI › Configurar › Geral › API: habilite a API REST e o login com token externo; crie um cliente de API (gera o App-Token).
2. No usuário de integração: Preferências › Chaves de acesso remoto › gerar token de API (user_token). Ele precisa enxergar os usuários das entidades desejadas.
3. No sistema, aba GLPI: informe URL, tokens e a OU (padrão `CE`), teste e sincronize.

Usuários que saem da OU são marcados como inativos. Loja e CRM de cada vendedor são ajustados na mesma tela.

## Configurar o Google Drive

1. No Google Cloud: crie um projeto, ative **Google Drive API** e **Google Sheets API**, crie uma conta de serviço e baixe a chave JSON.
2. Compartilhe a planilha e a pasta com o e-mail da conta de serviço como Editor.
   Para enviar arquivos `.xlsx`, use uma pasta em **Drive compartilhado** (contas de serviço não têm cota própria).
3. Na aba Google Drive envie o JSON, informe pasta, planilha, aba e loja.

## Observações

- O cabeçalho `DOC. EMPLACAMENTO ENTO CONSULTOR` foi mantido exatamente como na especificação homologada; se o correto for outro texto, ajuste em `config/veiculos.php`.
- `PLACA` não está entre as colunas homologadas, mas a consulta de carros exige placa; ela é aceita como coluna opcional e editável pelo perfil Entrega.
- A importação trata a planilha como fonte da verdade: células vazias limpam o campo correspondente.
- Para HTTPS, coloque um proxy reverso (ou certificado no Nginx) na frente da porta 8080.
