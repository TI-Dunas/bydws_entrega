#!/bin/sh
set -e
cd /var/www/html
KEYFILE=storage/app/.app_key

# Chave da aplicação persistida no volume
if [ -z "$APP_KEY" ]; then
  if [ "$ROLE" = "app" ] && [ ! -s "$KEYFILE" ]; then
    mkdir -p storage/app
    echo "base64:$(head -c 32 /dev/urandom | base64)" > "$KEYFILE"
  fi
  while [ ! -s "$KEYFILE" ]; do echo "Aguardando APP_KEY..."; sleep 2; done
  export APP_KEY="$(cat "$KEYFILE")"
fi

mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs storage/app/private

if [ "$ROLE" = "app" ]; then
  php artisan migrate --force
  php artisan db:seed --force
  php artisan view:cache
  chown -R www-data:www-data storage bootstrap/cache
else
  # scheduler: aguarda as migrações do container app
  until php artisan migrate:status >/dev/null 2>&1; do sleep 3; done
  chown -R www-data:www-data storage
fi

if [ "$ROLE" = "app" ]; then
  exec "$@"
fi
# demais papéis rodam como www-data para não criar arquivos de root no storage
exec setpriv --reuid=www-data --regid=www-data --init-groups "$@"
